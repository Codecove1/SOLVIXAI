require('dotenv').config();
const express = require('express');
const multer = require('multer');
const upload = multer();
const auth = require('./auth');
const rateLimiter = require('./rateLimiter');
const db = require('./db');
const whisper = require('./whisper');
const billing = require('./billing');

const app = express();
app.use(express.json());
app.use(rateLimiter);

app.post('/auth/login', auth.login);
app.post('/auth/register', auth.register);

app.post('/whisper', auth.requireAuthOptional, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'no file' });
    const transcript = await whisper.transcribeBuffer(req.file.buffer, req.user);
    res.json({ transcript });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'transcription_failed' });
  }
});

app.post('/billing/webhook', billing.handleWebhook);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on ${port}`));

module.exports = app;