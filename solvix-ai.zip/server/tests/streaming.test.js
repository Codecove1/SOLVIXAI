const request = require('supertest');
const app = require('../index');

describe('whisper endpoint', () => {
  it('accepts a small audio file', async () => {
    const res = await request(app)
      .post('/whisper')
      .attach('file', Buffer.from('dummy audio data'), 'dummy.webm');

    expect(res.statusCode).toBe(200);
    expect(res.body.transcript).toBeDefined();
  });
});