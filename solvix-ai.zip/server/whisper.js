module.exports = {
  transcribeBuffer: async (buffer, user) => {
    if (user && user.id) {
      try {
        const db = require('./db');
        db.recordUsage(user.id, 0.01);
      } catch (e) {
        console.warn('failed to record usage', e.message);
      }
    }
    return `transcript (simulated) — ${Math.round(buffer.length / 1000)} KB received`;
  }
};