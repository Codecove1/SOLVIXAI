module.exports = {
  handleWebhook: (req, res) => {
    console.log('billing webhook payload', req.body);
    res.json({ ok: true });
  }
};