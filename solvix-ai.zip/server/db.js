const path = require('path');
const Database = require('better-sqlite3');
const dbFile = path.join(__dirname, 'data.sqlite3');
const db = new Database(dbFile);

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE,
  password TEXT
);

CREATE TABLE IF NOT EXISTS usage (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  cost REAL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
`);

module.exports = {
  createUser: (email, password) => {
    const stmt = db.prepare('INSERT INTO users (email, password) VALUES (?, ?)');
    const info = stmt.run(email, password);
    return { id: info.lastInsertRowid, email };
  },
  findUserByEmail: (email) => db.prepare('SELECT * FROM users WHERE email = ?').get(email),
  recordUsage: (userId, cost) => {
    db.prepare('INSERT INTO usage (user_id, cost) VALUES (?, ?)').run(userId, cost);
  }
};