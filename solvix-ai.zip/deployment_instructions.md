# Deployment

## Docker Compose (local/prod)
1. Ensure Docker and docker-compose are installed.
2. Copy `.env.example` to `.env` in server and client.
3. Run `docker-compose up --build`.
4. Access client at http://localhost:8080 and server at http://localhost:3000.

## GitHub Actions
- Pushes to `main` branch trigger CI build + tests.
- Extend the workflow to deploy to your host (e.g. Docker Hub + Render/Kubernetes).

## Production tips
- Use strong JWT_SECRET.
- Hook billing.js to Stripe webhooks.
- Use HTTPS in production.
