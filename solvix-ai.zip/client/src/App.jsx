import React, { useState } from 'react';

export default function App() {
  const [status, setStatus] = useState('idle');
  const [transcript, setTranscript] = useState('');

  async function recordAndSend() {
    setStatus('requesting microphone...');
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const mediaRecorder = new MediaRecorder(stream);
    const chunks = [];

    mediaRecorder.ondataavailable = e => chunks.push(e.data);
    mediaRecorder.onstop = async () => {
      setStatus('sending to server...');
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const fd = new FormData();
      fd.append('file', blob, 'recording.webm');

      try {
        const token = localStorage.getItem('jwt');
        const res = await fetch(import.meta.env.VITE_API_URL + '/whisper', {
          method: 'POST',
          headers: token ? { 'Authorization': 'Bearer ' + token } : undefined,
          body: fd,
        });
        const data = await res.json();
        setTranscript(JSON.stringify(data, null, 2));
        setStatus('idle');
      } catch (err) {
        console.error(err);
        setStatus('error');
      }
    };

    mediaRecorder.start();
    setStatus('recording...');
    setTimeout(() => mediaRecorder.stop(), 4000);
  }

  return (
    <div>
      <h1>Solvix AI — Client</h1>
      <p>Status: {status}</p>
      <button onClick={recordAndSend}>Start Recording</button>
      <pre>{transcript}</pre>
    </div>
  );
}