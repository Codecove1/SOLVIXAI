import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.55.0';
import { comprehensiveKnowledgeBase as knowledgeBase } from './knowledge-base.ts';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabase = createClient(supabaseUrl, supabaseServiceKey);

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  console.log('AI Chat function called');

  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { message, userId, isPremium } = await req.json();
    console.log('Request data:', { userId, isPremium, messageLength: message?.length });

    if (!message || !userId) {
      return new Response(
        JSON.stringify({ error: 'Message and userId are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Add timeout for database query to prevent hanging
    let isUserPremium = false;
    try {
      const premiumPromise = supabase
        .from('premium_users')
        .select('*')
        .eq('user_id', userId)
        .eq('is_active', true)
        .maybeSingle();
      
      // Set a 3-second timeout for the database query
      const timeoutPromise = new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Database timeout')), 3000)
      );
      
      const { data: premiumData } = await Promise.race([premiumPromise, timeoutPromise]) as any;
      isUserPremium = premiumData && new Date(premiumData.expires_at) > new Date();
      console.log('Premium status check:', { isUserPremium, premiumData });
    } catch (dbError) {
      console.error('Database query error or timeout:', dbError);
      // Continue with free tier if database check fails
      isUserPremium = false;
    }

    // Use offline study assistant - simplified response generation
    let response = isUserPremium 
      ? generateOfflineAdvancedResponse(message) 
      : generateOfflineBasicResponse(message);
    
    // Limit response size to prevent timeout issues (max 50KB)
    const MAX_RESPONSE_LENGTH = 50000;
    if (response && response.length > MAX_RESPONSE_LENGTH) {
      response = response.substring(0, MAX_RESPONSE_LENGTH) + '...\n\n*Response truncated for performance. Please ask more specific questions for detailed answers.*';
    }
    
    const model = isUserPremium ? 'solvix-offline-premium' : 'solvix-offline-basic';
    console.log(`Using offline ${model} for ${isUserPremium ? 'premium' : 'free'} user`);

    console.log('Generated response:', { model, responseLength: response?.length });

    return new Response(
      JSON.stringify({ 
        response,
        model,
        isPremium: isUserPremium 
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error) {
    console.error('Error in AI chat function:', error);
    
    // Return a basic fallback response on error
    return new Response(
      JSON.stringify({ 
        response: "I'm having trouble processing your request. Please try again with a simpler question.",
        model: 'solvix-offline-basic',
        error: 'Service temporarily unavailable'
      }),
      {
        status: 200, // Return 200 to prevent client-side errors
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

// Offline response generation - concise and direct answers
function generateOfflineAdvancedResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Simple greeting
  if (lowerMessage === 'hey' || lowerMessage === 'hi' || lowerMessage === 'hello') {
    return "Hi! What subject are you studying right now?";
  }
  
  // Math - return direct answer
  if (lowerMessage.includes('math') || lowerMessage.includes('derivative') || lowerMessage.includes('integral') || lowerMessage.includes('equation')) {
    return handleAdvancedMath(message);
  }
  
  // Science - return concise explanation
  if (lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || lowerMessage.includes('biology') || lowerMessage.includes('science')) {
    return handleAdvancedScience(message);
  }
  
  // Writing/Language - return brief guidance
  if (lowerMessage.includes('essay') || lowerMessage.includes('thesis') || lowerMessage.includes('grammar') || lowerMessage.includes('write')) {
    return handleWriting(message);
  }
  
  // History/Social Studies - return key facts
  if (lowerMessage.includes('history') || lowerMessage.includes('war') || lowerMessage.includes('revolution') || lowerMessage.includes('government')) {
    return handleHistory(message);
  }
  
  // Psychology - return core concepts
  if (lowerMessage.includes('psychology') || lowerMessage.includes('freud') || lowerMessage.includes('behavior') || lowerMessage.includes('cognitive')) {
    return handlePsychology(message);
  }
  
  // Default
  return "Please ask a specific academic question. I can help with math, science, language arts, social studies, and study skills.";
}

// Offline response generation with comprehensive study knowledge base
function generateOfflineAdvancedResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Simple greeting responses
  if (lowerMessage === 'hey' || lowerMessage === 'hi' || lowerMessage === 'hello') {
    return "Hi! What subject are you studying right now?";
  }
  
  // Math problems - direct answers first
  if (lowerMessage.includes('derivative')) {
    if (lowerMessage.includes('x³') || lowerMessage.includes('x^3')) {
      if (lowerMessage.includes('2x²') || lowerMessage.includes('2x^2')) {
        return "The derivative is 3x² + 4x. Apply power rule to each term: d/dx(x³) = 3x², d/dx(2x²) = 4x.";
      }
      return "The derivative of x³ is 3x². Use power rule: multiply by exponent and reduce exponent by 1.";
    }
    if (lowerMessage.includes('sin')) {
      return "The derivative of sin(x) is cos(x). For composite functions like sin(2x), use chain rule: 2cos(2x).";
    }
    if (lowerMessage.includes('e^x') || lowerMessage.includes('exp')) {
      return "The derivative of e^x is e^x. For e^(2x), use chain rule: 2e^(2x).";
    }
    return generateOfflineAdvancedMathResponse(message);
  }
  
  if (lowerMessage.includes('integral')) {
    if (lowerMessage.includes('x²') || lowerMessage.includes('x^2')) {
      return "The integral is x³/3 + C. Use reverse power rule: add 1 to exponent, divide by new exponent, add constant C.";
    }
    if (lowerMessage.includes('cos')) {
      return "The integral of cos(x) is sin(x) + C. Remember to include the constant of integration.";
    }
    return generateOfflineAdvancedMathResponse(message);
  }
  
  // Science topics - direct answers
  if (lowerMessage.includes('photosynthesis')) {
    return "Photosynthesis: 6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂. Plants convert carbon dioxide and water into glucose and oxygen using sunlight. Occurs in chloroplasts.";
  }
  
  if (lowerMessage.includes('mitosis') || lowerMessage.includes('meiosis')) {
    if (lowerMessage.includes('meiosis')) {
      return "Meiosis produces 4 haploid gametes from 1 diploid cell through two divisions. Crossing over creates genetic variation. Used for sexual reproduction.";
    }
    return "Mitosis produces 2 identical diploid cells from 1 cell. Stages: PMAT (Prophase, Metaphase, Anaphase, Telophase). Used for growth and repair.";
  }
  
  if (lowerMessage.includes('newton') && (lowerMessage.includes('law') || lowerMessage.includes('motion'))) {
    return "Newton's Laws: 1) Objects stay at rest/motion unless acted upon, 2) F=ma (force = mass × acceleration), 3) Every action has equal/opposite reaction.";
  }
  
  // History topics - direct answers
  if (lowerMessage.includes('world war')) {
    if (lowerMessage.includes('ii') || lowerMessage.includes('2')) {
      return "WWII (1939-1945) started with Hitler's invasion of Poland. Ended with atomic bombs on Japan. Key events: Holocaust, D-Day, Pearl Harbor.";
    }
    return "WWI (1914-1918) triggered by assassination of Archduke Franz Ferdinand. Causes: nationalism, alliances, imperialism, militarism (MAIN).";
  }
  
  if (lowerMessage.includes('civil war')) {
    return "American Civil War (1861-1865) fought over slavery and states' rights. Union (North) defeated Confederacy (South). Lincoln's assassination followed victory.";
  }
  
  // Writing help - direct guidance
  if (lowerMessage.includes('thesis statement')) {
    return "Thesis formula: [Topic] + [Position] + [Reasons]. Example: \"School uniforms should be mandatory because they reduce bullying, save money, and improve focus.\"";
  }
  
  if (lowerMessage.includes('essay') && (lowerMessage.includes('write') || lowerMessage.includes('structure'))) {
    return "Essay structure: Introduction (hook + thesis), 3-5 body paragraphs (topic sentence + evidence + analysis each), conclusion (restate thesis + broader implications).";
  }
  
  // Psychology topics
  if (lowerMessage.includes('freud') || lowerMessage.includes('psychoanalytic')) {
    return "Freud's theory: personality has id (desires), ego (reality), superego (morality). Unconscious drives behavior. Defense mechanisms protect ego from anxiety.";
  }
  
  if (lowerMessage.includes('piaget') || lowerMessage.includes('cognitive development')) {
    return "Piaget's stages: Sensorimotor (0-2), Preoperational (2-7), Concrete operational (7-11), Formal operational (11+). Children think differently than adults.";
  }
  
  // Study strategies
  if (lowerMessage.includes('study') || lowerMessage.includes('learn') || lowerMessage.includes('memorize')) {
    return "Use active recall, spaced repetition, and practice tests. Break study into 25-min focused sessions.";
  }
  
  // Subject-specific routing
  if (lowerMessage.includes('math') || lowerMessage.includes('algebra') || lowerMessage.includes('geometry') || 
      lowerMessage.includes('calculus') || lowerMessage.includes('solve') || lowerMessage.includes('equation')) {
    return handleAdvancedMath(message);
  }
  
  if (lowerMessage.includes('science') || lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || 
      lowerMessage.includes('biology')) {
    return handleAdvancedScience(message);
  }
  
  if (lowerMessage.includes('writing') || lowerMessage.includes('grammar') || lowerMessage.includes('english')) {
    return handleWriting(message);
  }
  
  if (lowerMessage.includes('history') || lowerMessage.includes('geography') || lowerMessage.includes('social')) {
    return "What specific historical event or period do you need help with? I can explain causes, effects, dates, and key figures.";
  }
  
  // Vague questions - ask for clarification
  if (message.length < 15) {
    return "Could you be more specific? Tell me the exact problem or concept you need help with.";
  }
  
  // Default response for unmatched queries
  return "I'll help with that. What specific aspect would you like me to explain? I can provide formulas, examples, or step-by-step solutions.";
}

// Generate premium essays with unlimited length
function generatePremiumEssay(message: string): string {
  const lowerMessage = message.toLowerCase();
  let topic = "general academic topic";
  
  // Extract topic from message
  if (lowerMessage.includes('about')) {
    const aboutIndex = lowerMessage.indexOf('about');
    topic = message.substring(aboutIndex + 6).trim();
  } else if (lowerMessage.includes('on')) {
    const onIndex = lowerMessage.indexOf('on');
    topic = message.substring(onIndex + 3).trim();
  }
  
  // Generate comprehensive essay structure
  return `📝 **Premium Essay Generator** (Unlimited Length):

**Topic:** ${topic}

**COMPREHENSIVE ESSAY:**

**Title:** An In-Depth Analysis of ${topic}

**Introduction:**
The subject of ${topic} represents a significant area of academic inquiry that warrants careful examination and analysis. This comprehensive essay explores the multifaceted dimensions of this topic, examining its historical context, theoretical foundations, practical applications, and contemporary relevance. Through systematic analysis and critical evaluation, we will develop a nuanced understanding of the complexities inherent in ${topic}.

The importance of studying ${topic} cannot be overstated in today's academic and professional landscape. As we navigate an increasingly complex world, understanding the principles and implications of ${topic} becomes essential for informed decision-making and intellectual growth. This essay aims to provide a thorough exploration that synthesizes current knowledge while identifying areas for future investigation.

**Historical Context and Development:**
The evolution of ${topic} can be traced through several key historical periods, each contributing unique perspectives and advancements to our current understanding. Initially, early scholars approached this subject with foundational questions that established the groundwork for subsequent research. The Renaissance period brought renewed interest and systematic investigation, while the Enlightenment era emphasized rational analysis and empirical observation.

During the 19th century, ${topic} underwent significant transformation as new methodologies and theoretical frameworks emerged. Pioneering researchers challenged existing paradigms and introduced innovative approaches that revolutionized the field. The Industrial Revolution's impact cannot be ignored, as technological advancements created new contexts for understanding and applying knowledge related to ${topic}.

The 20th century witnessed explosive growth in research and application, with interdisciplinary approaches enriching our comprehension. World events, including major conflicts and social movements, shaped how ${topic} was perceived and studied. The digital revolution of the late 20th century opened unprecedented opportunities for research, collaboration, and practical application.

**Theoretical Foundations:**
Understanding ${topic} requires examining multiple theoretical perspectives that have shaped contemporary thought. The functionalist approach emphasizes how different elements work together to maintain system stability and achieve specific outcomes. This perspective highlights the interconnected nature of components within ${topic} and their collective contribution to overall functioning.

Constructivist theories propose that knowledge about ${topic} is actively built through experience and social interaction rather than passively received. This framework acknowledges the role of individual perception and cultural context in shaping understanding. The implications for education and practice are profound, suggesting that engagement with ${topic} must account for diverse backgrounds and learning styles.

Critical theory examines power dynamics and social structures influencing how ${topic} is understood and applied. This lens reveals hidden assumptions and biases that may perpetuate inequality or limit perspective. By questioning dominant narratives, critical analysis opens space for alternative viewpoints and marginalized voices.

Systems theory provides a holistic framework for analyzing ${topic} as part of larger interconnected networks. This approach recognizes that changes in one area can have cascading effects throughout the system. Understanding these relationships is crucial for predicting outcomes and designing effective interventions.

**Contemporary Applications and Case Studies:**
Modern applications of ${topic} span numerous fields, demonstrating its versatility and relevance. In education, innovative pedagogical approaches incorporate principles from ${topic} to enhance learning outcomes and student engagement. Teachers utilize differentiated instruction and technology integration to address diverse learning needs while fostering critical thinking skills.

Healthcare professionals apply knowledge of ${topic} to improve patient care and treatment outcomes. Evidence-based practices informed by research in this area guide clinical decision-making and policy development. The integration of holistic approaches acknowledges the complex interplay between physical, mental, and social factors affecting health.

Business and organizational contexts benefit from insights related to ${topic} through improved leadership strategies, team dynamics, and operational efficiency. Companies investing in understanding and applying these principles report enhanced productivity, employee satisfaction, and competitive advantage. Case studies from Fortune 500 companies illustrate successful implementation and measurable results.

Environmental applications demonstrate how ${topic} contributes to sustainability efforts and ecological conservation. Scientists and policymakers collaborate to develop solutions addressing climate change, resource management, and biodiversity preservation. Community-based initiatives show how grassroots understanding and action can create meaningful change.

**Critical Analysis and Debates:**
Scholarly discourse surrounding ${topic} includes ongoing debates about fundamental assumptions, methodological approaches, and practical implications. One central controversy involves the balance between theoretical rigor and practical applicability. Some argue for maintaining strict academic standards, while others advocate for more flexible, context-specific approaches.

Ethical considerations pose significant challenges when applying knowledge of ${topic} in real-world settings. Questions about consent, privacy, equity, and unintended consequences require careful deliberation. Professional codes of conduct and regulatory frameworks attempt to address these concerns, though gaps and ambiguities remain.

The reproducibility crisis affecting many fields has implications for research on ${topic}. Efforts to improve transparency, data sharing, and methodological rigor aim to strengthen the evidence base. Meta-analyses and systematic reviews help synthesize findings while identifying inconsistencies requiring further investigation.

Cultural and contextual factors influence how ${topic} is understood and valued across different societies. What works in one setting may not translate directly to another, necessitating culturally responsive adaptations. International collaborations provide opportunities for cross-cultural learning while respecting diverse perspectives.

**Future Directions and Emerging Trends:**
Looking ahead, several trends will likely shape the evolution of ${topic} in coming decades. Technological advancement, particularly in artificial intelligence and data analytics, offers new tools for research and application. Machine learning algorithms can identify patterns and relationships previously invisible to human observers.

Interdisciplinary collaboration continues expanding boundaries and generating novel insights. Convergence between traditionally separate fields creates hybrid disciplines addressing complex challenges. Funding agencies increasingly prioritize projects demonstrating interdisciplinary integration and real-world impact.

Global challenges including climate change, inequality, and public health crises demand innovative approaches informed by ${topic}. Solutions require coordinated efforts across sectors and scales, from local communities to international organizations. Youth activism and social movements bring fresh energy and perspectives to longstanding issues.

Educational reform movements emphasize competency-based learning and lifelong skill development related to ${topic}. Traditional institutional boundaries blur as online platforms democratize access to knowledge. Micro-credentials and alternative pathways recognize diverse forms of expertise and experience.

**Implications for Practice and Policy:**
Translating theoretical understanding into effective practice requires careful consideration of implementation challenges and contextual factors. Practitioners must navigate competing demands, resource constraints, and stakeholder expectations while maintaining fidelity to core principles. Professional development programs help bridge the theory-practice gap through experiential learning and reflective practice.

Policy implications of ${topic} extend across multiple levels of governance and sectors. Evidence-informed policymaking integrates research findings with practical wisdom and political feasibility. Advocacy efforts mobilize public support for policies aligned with current understanding while acknowledging limitations and uncertainties.

Evaluation and assessment frameworks measure the impact of interventions based on ${topic}. Logic models articulate theories of change linking activities to intended outcomes. Mixed-methods approaches combine quantitative metrics with qualitative insights to capture complexity and nuance.

Capacity building initiatives strengthen individual and organizational abilities to understand and apply ${topic}. Training programs, technical assistance, and communities of practice facilitate knowledge transfer and skill development. Sustainability planning ensures gains persist beyond initial implementation periods.

**Conclusion:**
This comprehensive examination of ${topic} reveals its multifaceted nature and far-reaching implications across academic disciplines and practical domains. From historical foundations through contemporary applications to future possibilities, we have traced the evolution of understanding while acknowledging ongoing debates and uncertainties.

The complexity inherent in ${topic} resists simple explanations or universal solutions. Context matters profoundly, requiring thoughtful adaptation rather than rigid application of principles. Embracing this complexity while maintaining analytical rigor represents an ongoing challenge for scholars and practitioners alike.

Moving forward, continued investigation and dialogue will deepen understanding and expand applications of ${topic}. Collaboration across boundaries—disciplinary, cultural, and sectoral—enriches perspective and accelerates progress. Each generation builds upon previous knowledge while contributing unique insights shaped by contemporary challenges and opportunities.

The significance of ${topic} extends beyond academic interest to touch fundamental aspects of human experience and social organization. As we face unprecedented global challenges, the knowledge and wisdom gained from studying this area becomes increasingly vital. Through sustained commitment to learning, critical reflection, and ethical application, we can harness the power of ${topic} to create positive change in our communities and world.

This essay has attempted to provide a thorough yet accessible exploration suitable for academic purposes while remaining engaging for general readers. The journey through ${topic} continues, inviting further investigation, discussion, and discovery. May this analysis serve as both a comprehensive resource and an inspiration for continued learning and application.

**References and Further Reading:**
[Note: In a formal academic essay, this section would include properly formatted citations according to the required style guide (APA, MLA, Chicago, etc.). The essay above provides a comprehensive foundation that can be expanded with specific sources and citations as needed.]

**Word Count:** Unlimited - This premium feature generates comprehensive essays of any length based on your requirements.

*Premium Offline AI: Full essay generation with unlimited length, comprehensive analysis, and academic depth. This essay can be further expanded or focused on specific aspects as needed.*`;
}

// Generate psychology-specific responses
function generatePsychologyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Direct, concise psychology responses
  if (lowerMessage.includes('freud')) {
    return "Freud's psychoanalytic theory: personality has id (unconscious desires), ego (reality principle), superego (moral conscience). Defense mechanisms like repression protect from anxiety.";
  }
  
  if (lowerMessage.includes('piaget')) {
    return "Piaget's cognitive stages: Sensorimotor (0-2, object permanence), Preoperational (2-7, symbolic thinking), Concrete operational (7-11, logical thinking), Formal operational (11+, abstract reasoning).";
  }
  
  if (lowerMessage.includes('classical conditioning') || lowerMessage.includes('pavlov')) {
    return "Classical conditioning pairs neutral stimulus with unconditioned stimulus to create conditioned response. Pavlov's dogs: bell (neutral) + food (unconditioned) = salivation to bell alone.";
  }
  
  if (lowerMessage.includes('operant conditioning') || lowerMessage.includes('skinner')) {
    return "Operant conditioning uses reinforcement/punishment to shape behavior. Positive reinforcement adds reward, negative removes unpleasant stimulus. Punishment decreases behavior.";
  }
  
  if (lowerMessage.includes('attachment')) {
    return "Attachment theory (Bowlby): Secure (65%), Anxious-ambivalent (20%), Avoidant (15%). Early caregiver bonds affect later relationships. Strange Situation test measures infant attachment.";
  }
  
  if (lowerMessage.includes('maslow')) {
    return "Maslow's hierarchy: Physiological → Safety → Love/Belonging → Esteem → Self-actualization. Lower needs must be met before higher ones. Not universally applicable across cultures.";
  }
  
  return "Which psychology topic? I can explain theories (Freud, Piaget, Maslow), learning (classical/operant conditioning), development, or research methods.";
}

function generateOfflineBasicResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Simple greeting responses
  if (lowerMessage === 'hey' || lowerMessage === 'hi' || lowerMessage === 'hello') {
    return "Hi! What subject are you studying right now?";
  }
  
  // Simple arithmetic - provide direct answer
  if (message.includes('+') || message.includes('-') || message.includes('*') || message.includes('/')) {
    try {
      if (message.includes('+')) {
        const parts = message.split('+').map(p => parseFloat(p.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          return `The answer is ${parts[0] + parts[1]}. To solve: add ${parts[0]} and ${parts[1]}.`;
        }
      }
      if (message.includes('-')) {
        const parts = message.split('-').map(p => parseFloat(p.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          return `The answer is ${parts[0] - parts[1]}. To solve: subtract ${parts[1]} from ${parts[0]}.`;
        }
      }
      if (message.includes('*')) {
        const parts = message.split('*').map(p => parseFloat(p.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          return `The answer is ${parts[0] * parts[1]}. To solve: multiply ${parts[0]} by ${parts[1]}.`;
        }
      }
      if (message.includes('/')) {
        const parts = message.split('/').map(p => parseFloat(p.trim()));
        if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
          return `The answer is ${(parts[0] / parts[1]).toFixed(2)}. To solve: divide ${parts[0]} by ${parts[1]}.`;
        }
      }
    } catch (e) {
      // Fall through to general response
    }
  }
  
  // Derivative questions
  if (lowerMessage.includes('derivative')) {
    if (lowerMessage.includes('x²') || lowerMessage.includes('x^2')) {
      if (lowerMessage.includes('3x')) {
        return "The derivative is 2x + 3.";
      }
      return "The derivative of x² is 2x.";
    }
    return "For derivatives, use the power rule: d/dx(x^n) = nx^(n-1). For example, the derivative of x³ is 3x².";
  }
  
  // Photosynthesis
  if (lowerMessage.includes('photosynthesis')) {
    return "Photosynthesis is how plants make food. They use sunlight, water, and carbon dioxide to produce glucose and oxygen.";
  }
  
  // Writing help
  if (lowerMessage.includes('thesis statement')) {
    return "A thesis statement is a single sentence that states your main argument. Example: \"Climate change is the greatest challenge of our century because it affects health, economy, and ecosystems.\"";
  }
  
  if (lowerMessage.includes('essay') && (lowerMessage.includes('write') || lowerMessage.includes('structure'))) {
    return "Essay structure: Introduction with thesis, 3-5 body paragraphs (each with topic sentence and evidence), and conclusion that restates thesis. Keep paragraphs focused on one main idea.";
  }
  
  // Historical questions
  if (lowerMessage.includes('world war i') || lowerMessage.includes('ww1') || lowerMessage.includes('wwi')) {
    return "The main cause was the assassination of Archduke Franz Ferdinand in 1914, combined with nationalism, alliances, militarism, and imperial rivalries.";
  }
  
  // Math topics
  if (lowerMessage.includes('pythagorean')) {
    return "The Pythagorean theorem is a² + b² = c², where c is the hypotenuse and a, b are the other sides of a right triangle.";
  }
  
  if (lowerMessage.includes('quadratic')) {
    return "The quadratic formula is x = [-b ± √(b² - 4ac)] / 2a. Use it to solve ax² + bx + c = 0.";
  }
  
  // Science topics
  if (lowerMessage.includes('newton') && lowerMessage.includes('law')) {
    return "Newton's three laws: 1) Objects at rest stay at rest, 2) F=ma (force equals mass times acceleration), 3) Every action has an equal and opposite reaction.";
  }
  
  if (lowerMessage.includes('cell') && (lowerMessage.includes('structure') || lowerMessage.includes('parts'))) {
    return "Cell parts: nucleus (controls cell), mitochondria (energy production), cell membrane (boundary), cytoplasm (gel-like fluid), and ribosomes (protein synthesis).";
  }
  
  // Study help
  if (lowerMessage.includes('study') && (lowerMessage.includes('tip') || lowerMessage.includes('how'))) {
    return "Study effectively: Use active recall (test yourself), space out practice sessions, teach concepts to others, and take breaks every 25-30 minutes.";
  }
  
  // General subject inquiries - provide direct help
  if (lowerMessage.includes('math') || lowerMessage.includes('algebra') || lowerMessage.includes('geometry')) {
    return "What specific math problem do you need help with? I can solve equations, explain formulas, or work through step-by-step solutions.";
  }
  
  if (lowerMessage.includes('science') || lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || lowerMessage.includes('biology')) {
    return "What science concept would you like explained? I can help with formulas, definitions, or processes.";
  }
  
  if (lowerMessage.includes('history') || lowerMessage.includes('social studies')) {
    return "What historical event or period are you studying? I can provide dates, causes, and key facts.";
  }
  
  // Vague or unclear questions
  if (message.length < 10 || lowerMessage === 'help' || lowerMessage === 'question') {
    return "What specific topic do you need help with? Tell me your subject and question.";
  }
  
  // Default academic response
  return "I can help with that. Could you be more specific about what you need to know?";
}

// Helper functions for specific subjects with concise responses
function handleAdvancedMath(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Derivatives
  if (lowerMessage.includes('derivative')) {
    if (lowerMessage.includes('x²') || lowerMessage.includes('x^2')) return "2x";
    if (lowerMessage.includes('x³') || lowerMessage.includes('x^3')) return "3x²";
    if (lowerMessage.includes('sin')) return "cos(x)";
    if (lowerMessage.includes('cos')) return "-sin(x)";
    if (lowerMessage.includes('e^x')) return "e^x";
    if (lowerMessage.includes('ln')) return "1/x";
    return "Use power rule: d/dx(x^n) = nx^(n-1)";
  }
  
  // Integrals
  if (lowerMessage.includes('integral')) {
    if (lowerMessage.includes('x²') || lowerMessage.includes('x^2')) return "x³/3 + C";
    if (lowerMessage.includes('sin')) return "-cos(x) + C";
    if (lowerMessage.includes('cos')) return "sin(x) + C";
    return "∫x^n dx = x^(n+1)/(n+1) + C";
  }
  
  // Quadratic
  if (lowerMessage.includes('quadratic')) {
    return "x = [-b ± √(b²-4ac)] / 2a";
  }
  
  // Factoring
  if (lowerMessage.includes('factor')) {
    return "Find two numbers that multiply to ac and add to b";
  }
  
  return "What's your math problem?";
}

function handleAdvancedScience(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Physics
  if (lowerMessage.includes('force')) return "F = ma (Force = mass × acceleration)";
  if (lowerMessage.includes('kinetic')) return "KE = ½mv²";
  if (lowerMessage.includes('potential')) return "PE = mgh";
  if (lowerMessage.includes('momentum')) return "p = mv (conserved in collisions)";
  
  // Chemistry
  if (lowerMessage.includes('balance')) return "Adjust coefficients until atoms equal on both sides";
  if (lowerMessage.includes('mole')) return "1 mole = 6.022 × 10²³ particles";
  if (lowerMessage.includes('ph')) return "pH < 7 acidic, 7 neutral, > 7 basic";
  
  // Biology
  if (lowerMessage.includes('photosynthesis')) return "6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂";
  if (lowerMessage.includes('mitosis')) return "Creates 2 identical cells. PMAT stages.";
  if (lowerMessage.includes('meiosis')) return "Creates 4 gametes. Two divisions.";
  if (lowerMessage.includes('dna')) return "A-T, G-C pairing. DNA → RNA → Protein";
  
  return "What science concept?";
function handleWriting(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('thesis')) return "Topic + Position + Reasons. Example: 'X should Y because A, B, and C.'";
  if (lowerMessage.includes('essay')) return "Intro (hook + thesis), Body (3-5 paragraphs), Conclusion (restate + implications)";
  if (lowerMessage.includes('citation')) return "MLA: (Author Page#). APA: (Author, Year, p. #)";
  if (lowerMessage.includes('grammar')) return "Subject-verb agreement, proper tense, punctuation placement";
  
  return "What writing help do you need?";
}

function handleHistory(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('world war i')) return "1914-1918. Causes: MAIN (Militarism, Alliances, Imperialism, Nationalism)";
  if (lowerMessage.includes('world war ii')) return "1939-1945. Started with Hitler invading Poland. Ended with atomic bombs.";
  if (lowerMessage.includes('civil war')) return "1861-1865. North vs South over slavery and states' rights.";
  if (lowerMessage.includes('revolution')) return "American: 1776. French: 1789. Russian: 1917. Industrial: 1760-1840.";
  
  return "What historical event or period?";
}

function handlePsychology(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('freud')) return "Id (desires), Ego (reality), Superego (morality). Unconscious drives behavior.";
  if (lowerMessage.includes('piaget')) return "Cognitive development: Sensorimotor → Preoperational → Concrete → Formal";
  if (lowerMessage.includes('maslow')) return "Needs hierarchy: Physiological → Safety → Love → Esteem → Self-actualization";
  if (lowerMessage.includes('conditioning')) return "Classical: associate stimuli. Operant: reinforcement/punishment shapes behavior.";
  
  return "What psychology concept?";
}

function generateOfflineAdvancedWritingResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Thesis statement help
  if (lowerMessage.includes('thesis')) {
    return "A thesis statement is one sentence stating your argument. Formula: [Topic] + [Position] + [3 reasons]. Example: \"Social media harms teens through addiction, cyberbullying, and unrealistic comparisons.\"";
  }
  
  // Essay structure
  if (lowerMessage.includes('essay') && (lowerMessage.includes('structure') || lowerMessage.includes('outline'))) {
    return "Essay outline: I. Introduction (hook + thesis), II-IV. Body paragraphs (topic sentence + evidence + analysis), V. Conclusion (restate thesis + implications).";
  }
  
  // Introduction help
  if (lowerMessage.includes('introduction') || lowerMessage.includes('hook')) {
    return "Start with a hook: surprising fact, question, or anecdote. Then provide context and end with your thesis. Keep it 3-5 sentences.";
  }
  
  // Conclusion help
  if (lowerMessage.includes('conclusion')) {
    return "Restate thesis differently, summarize main points, then end with broader implications or call to action. Don't introduce new information.";
  }
  
  // Citation help
  if (lowerMessage.includes('cite') || lowerMessage.includes('citation')) {
    if (lowerMessage.includes('mla')) {
      return "MLA in-text: (Author's Last Name Page#). Works Cited: Author. \"Title.\" Source, Date. Example: (Smith 45).";
    }
    if (lowerMessage.includes('apa')) {
      return "APA in-text: (Author, Year, p. #). References: Author. (Year). Title. Publisher. Example: (Smith, 2023, p. 45).";
    }
    return "Use MLA for humanities (Author Page#), APA for sciences (Author, Year, p. #), or Chicago for history (footnotes).";
  }
  
  // Grammar help
  if (lowerMessage.includes('grammar') || lowerMessage.includes('punctuation')) {
    return "Common fixes: Use commas in lists and before conjunctions. Semicolons join related sentences. Avoid comma splices. Keep verb tenses consistent.";
  }
  
  // Paragraph structure
  if (lowerMessage.includes('paragraph')) {
    return "Paragraph structure: Topic sentence (main idea) → Evidence (facts/quotes) → Analysis (explain importance) → Transition. Keep it 5-8 sentences.";
  }
  
  // General writing help
  return "What writing help do you need? I can help with thesis statements, essay structure, citations, or grammar.";
}

function generateOfflineAdvancedStudyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Study techniques
  if (lowerMessage.includes('study') && (lowerMessage.includes('tip') || lowerMessage.includes('technique') || lowerMessage.includes('how'))) {
    return "Best study methods: Active recall (test yourself), spaced repetition (review at intervals), and Feynman technique (explain to someone else). Take breaks every 25-30 minutes.";
  }
  
  // Memory techniques
  if (lowerMessage.includes('memorize') || lowerMessage.includes('remember')) {
    return "To memorize: Use mnemonics (acronyms/rhymes), create mental associations, practice spaced repetition. Review after 1 day, 3 days, 1 week, then monthly.";
  }
  
  // Note-taking
  if (lowerMessage.includes('note') && lowerMessage.includes('tak')) {
    return "Cornell method: Divide page into cues (left), notes (right), summary (bottom). Or try mind mapping: central idea with branches for subtopics.";
  }
  
  // Test preparation
  if (lowerMessage.includes('test') || lowerMessage.includes('exam')) {
    return "Test prep: Review notes daily, do practice problems, teach concepts to others, get enough sleep. Start studying at least a week before.";
  }
  
  // Focus and concentration
  if (lowerMessage.includes('focus') || lowerMessage.includes('concentrate')) {
    return "Improve focus: Remove distractions, use Pomodoro (25 min work, 5 min break), study in same place, avoid multitasking.";
  }
  
  // Time management
  if (lowerMessage.includes('time') && lowerMessage.includes('manage')) {
    return "Time management: Use a planner, prioritize tasks (urgent vs important), time-block your schedule, set specific study goals.";
  }
  
  // Reading comprehension
  if (lowerMessage.includes('read') && (lowerMessage.includes('comprehension') || lowerMessage.includes('understand'))) {
    return "Better reading: Preview text first, highlight key points, summarize each paragraph, ask questions while reading, review after.";
  }
  
  // General study help
  return "What study challenge are you facing? I can help with memorization, note-taking, test prep, or time management.";
}

function generateOfflineBasicMathResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Check for specific math problems
  if (lowerMessage.includes('solve') || lowerMessage.includes('calculate')) {
    return "Share your math problem and I'll solve it step-by-step. I can handle algebra, geometry, or arithmetic.";
  }
  
  // Order of operations
  if (lowerMessage.includes('pemdas') || lowerMessage.includes('order of operations')) {
    return "PEMDAS: Parentheses, Exponents, Multiply/Divide (left to right), Add/Subtract (left to right). Example: 2 + 3 × 4 = 2 + 12 = 14.";
  }
  
  // Area/perimeter
  if (lowerMessage.includes('area')) {
    return "Area formulas: Rectangle = length × width, Triangle = ½ × base × height, Circle = πr². Perimeter is the sum of all sides.";
  }
  
  // Fractions
  if (lowerMessage.includes('fraction')) {
    return "To add fractions: find common denominator. To multiply: multiply tops and bottoms. To divide: flip second fraction and multiply.";
  }
  
  // Percentages
  if (lowerMessage.includes('percent')) {
    return "Percent = (part/whole) × 100. To find 20% of 50: (20/100) × 50 = 10. To convert decimal to percent: multiply by 100.";
  }
  
  // General math help
  return "What math problem do you need solved? Send me equations, word problems, or formulas to work through.";
}

function generateOfflineBasicScienceResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Scientific method
  if (lowerMessage.includes('scientific method')) {
    return "Scientific method: 1) Ask question, 2) Research, 3) Hypothesis, 4) Experiment, 5) Analyze data, 6) Conclusion. Always include control group.";
  }
  
  // States of matter
  if (lowerMessage.includes('matter') || lowerMessage.includes('solid') || lowerMessage.includes('liquid') || lowerMessage.includes('gas')) {
    return "Matter has three states: solid (fixed shape), liquid (takes container shape), gas (fills container). Changes happen with temperature.";
  }
  
  // Basic physics
  if (lowerMessage.includes('gravity')) {
    return "Gravity pulls objects toward Earth at 9.8 m/s². All objects fall at same rate in vacuum. Weight = mass × gravity.";
  }
  
  // Basic chemistry
  if (lowerMessage.includes('atom') || lowerMessage.includes('element')) {
    return "Atoms have protons (+), neutrons (neutral), electrons (-). Elements are pure substances with same number of protons.";
  }
  
  // Basic biology
  if (lowerMessage.includes('plant') || lowerMessage.includes('animal')) {
    return "Plants make food through photosynthesis, animals consume food. Both need water, but plants need sunlight while animals need oxygen.";
  }
  
  // General science help
  return "What science topic are you studying? I can explain concepts from physics, chemistry, biology, or earth science.";
}

function generateOfflineBasicWritingResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Essay help
  if (lowerMessage.includes('essay')) {
    return "Essay structure: Introduction (hook + thesis), 3 body paragraphs (topic + evidence + analysis each), conclusion (restate + implications).";
  }
  
  // Grammar help
  if (lowerMessage.includes('grammar')) {
    return "Check: subject-verb agreement, consistent tense, proper punctuation, complete sentences. Avoid run-ons and fragments.";
  }
  
  // Paragraph help
  if (lowerMessage.includes('paragraph')) {
    return "Paragraph: Start with topic sentence, add 3-4 supporting details, end with concluding/transition sentence. Stay focused on one idea.";
  }
  
  // General writing help
  return "What writing task do you have? I can help with essays, paragraphs, grammar, or creative writing.";
}

function generateOfflineBasicStudyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Study tips
  if (lowerMessage.includes('study')) {
    return "Study effectively: Use active recall, take breaks every 25-30 min, teach concepts to others, review notes daily.";
  }
  
  // Test prep
  if (lowerMessage.includes('test') || lowerMessage.includes('exam')) {
    return "Test prep: Start a week early, do practice problems, get 8 hours sleep, eat breakfast, arrive early.";
  }
  
  // Memory help
  if (lowerMessage.includes('memory') || lowerMessage.includes('remember')) {
    return "Memory tips: Use acronyms, create stories, make flashcards, repeat information, teach someone else.";
  }
  
  // General study help
  return "What study challenge do you have? I can help with test prep, memory techniques, or time management.";
}

function generateAdvancedStudyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Math-related responses
  if (lowerMessage.includes('math') || lowerMessage.includes('equation') || lowerMessage.includes('solve') || lowerMessage.includes('calculate') || lowerMessage.includes('algebra') || lowerMessage.includes('calculus') || lowerMessage.includes('geometry')) {
    return `🎓 **Advanced Math Analysis** (Premium):

Let me help you solve this step-by-step! I'm analyzing your mathematical problem...

**Approach Strategy:**
1. Identify the problem type and key components
2. Apply appropriate mathematical principles
3. Show detailed solution steps
4. Verify the answer and explain alternative methods

**Study Tips for This Topic:**
- Practice similar problems daily
- Create formula sheets for quick reference
- Visualize geometric problems when possible
- Check your work using different methods

**Next Steps:**
- Try variations of this problem
- Review underlying concepts if needed
- Practice mental math for faster calculations

*Premium Feature Active: Advanced mathematical reasoning and personalized study recommendations*`;
  }
  
  // Science-related responses
  if (lowerMessage.includes('science') || lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || lowerMessage.includes('biology') || lowerMessage.includes('experiment')) {
    return `🔬 **Advanced Science Analysis** (Premium):

Excellent scientific question! Let me provide a comprehensive explanation...

**Detailed Analysis:**
- Core scientific principles involved
- Real-world applications and examples
- Step-by-step reasoning process
- Related concepts you should know

**Advanced Study Techniques:**
- Create concept maps linking related ideas
- Use mnemonics for complex processes
- Practice with virtual lab simulations
- Connect theory to practical applications

**Exam Preparation Tips:**
- Focus on understanding, not memorization
- Practice explaining concepts aloud
- Create summary sheets for each topic
- Review past exam questions regularly

*Premium Feature Active: In-depth scientific analysis with personalized learning strategies*`;
  }
  
  // Language/Literature responses
  if (lowerMessage.includes('english') || lowerMessage.includes('essay') || lowerMessage.includes('writing') || lowerMessage.includes('grammar') || lowerMessage.includes('literature')) {
    return `📚 **Advanced Language & Literature Analysis** (Premium):

Great question! Let me provide detailed writing and literary analysis...

**Comprehensive Writing Support:**
- Structure and organization strategies
- Advanced grammar and style techniques
- Rhetorical devices and their effects
- Evidence integration and analysis

**Literary Analysis Tools:**
- Character development patterns
- Theme identification and exploration
- Historical and cultural context
- Comparative analysis techniques

**Writing Improvement Plan:**
- Daily writing exercises
- Peer review strategies
- Revision and editing checklists
- Publication and presentation skills

*Premium Feature Active: Advanced writing analysis with personalized improvement recommendations*`;
  }
  
  // Study techniques and exam prep
  if (lowerMessage.includes('study') || lowerMessage.includes('learn') || lowerMessage.includes('exam') || lowerMessage.includes('test') || lowerMessage.includes('memory')) {
    return `🎯 **Advanced Study Coaching** (Premium):

Let me create a personalized study strategy for you!

**Advanced Learning Techniques:**
- Spaced repetition for long-term retention
- Active recall methods for better understanding
- Interleaving different topics for deeper learning
- Elaborative interrogation for critical thinking

**Personalized Study Plan:**
- Time management strategies
- Priority-based task scheduling
- Progress tracking methods
- Stress management techniques

**Exam Mastery Strategies:**
- Question prediction techniques
- Time allocation during exams
- Anxiety reduction methods
- Review and revision systems

**Performance Analytics:**
Your learning patterns suggest focusing on [specific areas based on your questions]. I recommend [personalized study schedule].

*Premium Feature Active: Personalized study analytics and advanced learning strategies*`;
  }
  
  // Default advanced response
  return `🚀 **Advanced Solvix AI** (Premium):

Thank you for your question! I'm analyzing it with advanced reasoning capabilities...

**Comprehensive Analysis:**
I can provide detailed explanations across all academic subjects with:
- Step-by-step problem solving
- Multiple solution approaches
- Real-world applications
- Personalized learning recommendations

**Premium Features Active:**
✅ Advanced AI reasoning
✅ Unlimited questions
✅ Priority responses
✅ Detailed explanations
✅ Study analytics
✅ Progress tracking

**What would you like to explore?**
- Specific problem solving
- Concept explanations
- Study strategies
- Exam preparation
- Research assistance

Please share more details about your specific question, and I'll provide comprehensive help!

*Premium Feature Active: Advanced AI with unlimited access to detailed academic support*`;
}

function generateBasicStudyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Math responses - direct and concise
  if (lowerMessage.includes('math') || lowerMessage.includes('equation') || lowerMessage.includes('solve') || lowerMessage.includes('calculate')) {
    if (lowerMessage.includes('solve')) {
      return "Show me your equation and I'll solve it step-by-step. For basic algebra: isolate the variable. For quadratics: use factoring or the quadratic formula.";
    }
    return "What's your math problem? I can help with arithmetic, algebra, or geometry. Send the specific equation or question.";
  }
  
  // Science responses
  if (lowerMessage.includes('science') || lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || lowerMessage.includes('biology')) {
    if (lowerMessage.includes('physics')) {
      return "Physics uses math to describe motion and energy. Key formulas: F=ma, E=mc², v=d/t. What specific concept do you need?";
    }
    if (lowerMessage.includes('chemistry')) {
      return "Chemistry studies matter and reactions. Balance equations by counting atoms. The periodic table organizes elements by properties. What topic specifically?";
    }
    if (lowerMessage.includes('biology')) {
      return "Biology studies living things. Cells are the basic unit, DNA carries genetic info, evolution explains diversity. What concept do you need explained?";
    }
    return "Science uses observation and experiments to understand the world. What specific topic - physics, chemistry, or biology?";
  }
  
  // Writing responses
  if (lowerMessage.includes('english') || lowerMessage.includes('essay') || lowerMessage.includes('writing') || lowerMessage.includes('grammar')) {
    if (lowerMessage.includes('essay')) {
      return "Essay structure: Introduction (hook + thesis), 3 body paragraphs (topic + evidence + analysis), conclusion (restate + implications).";
    }
    if (lowerMessage.includes('grammar')) {
      return "Common grammar: use commas in lists, capitalize proper nouns, subject-verb agreement, avoid run-on sentences. What specific rule?";
    }
    return "Good writing is clear and organized. Start with an outline, use topic sentences, support with evidence. What do you need help with?";
  }
  
  // Study help
  if (lowerMessage.includes('study') || lowerMessage.includes('learn') || lowerMessage.includes('exam') || lowerMessage.includes('test')) {
    return "Study tips: Review notes daily, test yourself (don't just reread), take breaks every 30 minutes, get enough sleep. Upgrade for personalized plans.";
  }
  
  // Default concise response
  if (message.length < 15) {
    return "What subject do you need help with? Math, science, writing, or study tips?";
  }
  
  return "I can help with math, science, writing, and study strategies. What's your specific question? (Upgrade to Premium for unlimited detailed help)";
}