export const comprehensiveKnowledgeBase = {
  mathematics: {
    algebra: {
      basics: "Variables, expressions, equations, inequalities, functions",
      linear: "Slope-intercept form (y=mx+b), point-slope form, standard form, systems of equations",
      quadratic: "Factoring, completing square, quadratic formula, discriminant analysis",
      polynomial: "Operations, factoring techniques, rational expressions, complex numbers",
      exponential: "Growth/decay, logarithms, compound interest, natural base e"
    },
    calculus: {
      limits: "Definition, properties, continuity, L'Hôpital's rule",
      derivatives: "Power rule, product rule, quotient rule, chain rule, implicit differentiation",
      integrals: "Antiderivatives, definite integrals, substitution, integration by parts",
      applications: "Optimization, related rates, area, volume, differential equations"
    },
    geometry: {
      euclidean: "Points, lines, angles, triangles, quadrilaterals, circles, polygons",
      solid: "Prisms, pyramids, cylinders, cones, spheres, surface area, volume",
      coordinate: "Distance formula, midpoint, slope, transformations",
      proofs: "Direct, indirect, contradiction, mathematical induction"
    },
    statistics: {
      descriptive: "Mean, median, mode, range, variance, standard deviation, quartiles",
      probability: "Sample spaces, events, combinations, permutations, distributions",
      inferential: "Hypothesis testing, confidence intervals, z-tests, t-tests, chi-square",
      regression: "Linear, multiple, correlation, r-squared, residuals"
    }
  },
  sciences: {
    physics: {
      mechanics: "Kinematics, dynamics, energy, momentum, rotational motion, gravitation",
      waves: "Properties, sound, light, interference, diffraction, Doppler effect",
      electricity: "Coulomb's law, electric fields, circuits, Ohm's law, capacitance",
      magnetism: "Magnetic fields, electromagnetic induction, Maxwell's equations",
      modern: "Relativity, quantum mechanics, atomic structure, nuclear physics"
    },
    chemistry: {
      atomic: "Structure, electron configuration, periodic trends, bonding types",
      stoichiometry: "Mole concept, balanced equations, limiting reagents, percent yield",
      thermochemistry: "Enthalpy, entropy, Gibbs free energy, Hess's law",
      kinetics: "Rate laws, activation energy, catalysts, reaction mechanisms",
      equilibrium: "Le Chatelier's principle, Ksp, Ka/Kb, pH, buffers"
    },
    biology: {
      cellular: "Prokaryotes, eukaryotes, organelles, membranes, transport, respiration",
      genetics: "DNA, RNA, replication, transcription, translation, inheritance, mutations",
      evolution: "Natural selection, speciation, phylogeny, evidence, Hardy-Weinberg",
      ecology: "Populations, communities, ecosystems, biomes, cycles, conservation",
      physiology: "Nervous, circulatory, respiratory, digestive, endocrine, immune systems"
    }
  },
  psychology: {
    cognitive: {
      memory: "Encoding, storage, retrieval, working memory, long-term memory types",
      thinking: "Problem-solving, decision-making, creativity, intelligence theories",
      perception: "Sensation, attention, pattern recognition, depth perception"
    },
    developmental: {
      theories: "Piaget's stages, Erikson's stages, Vygotsky's ZPD, attachment theory",
      lifespan: "Prenatal, infancy, childhood, adolescence, adulthood, aging"
    },
    clinical: {
      disorders: "DSM-5 categories, anxiety, mood, psychotic, personality disorders",
      therapy: "CBT, psychodynamic, humanistic, behavioral, group, family therapy"
    },
    social: {
      influence: "Conformity, obedience, persuasion, group dynamics, leadership",
      cognition: "Attribution, attitudes, stereotypes, prejudice, impression formation"
    }
  },
  history: {
    periods: {
      ancient: "Mesopotamia, Egypt, Greece, Rome, China, India, Americas",
      medieval: "Feudalism, Crusades, Islamic Golden Age, Byzantine Empire",
      renaissance: "Humanism, art, science, exploration, Reformation",
      modern: "Enlightenment, revolutions, industrialization, imperialism, world wars",
      contemporary: "Cold War, decolonization, globalization, digital age"
    },
    themes: {
      political: "Government systems, revolutions, ideologies, international relations",
      economic: "Trade, industrialization, capitalism, socialism, globalization",
      social: "Class, gender, race, migration, urbanization, social movements",
      cultural: "Religion, art, literature, technology, ideas, cultural exchange"
    }
  },
  literature: {
    genres: {
      fiction: "Novels, short stories, novellas, flash fiction, genres and subgenres",
      poetry: "Forms, meters, devices, movements, analysis techniques",
      drama: "Tragedy, comedy, tragicomedy, structure, stagecraft",
      nonfiction: "Essays, biography, memoir, journalism, creative nonfiction"
    },
    analysis: {
      elements: "Plot, character, setting, theme, point of view, style, tone",
      devices: "Metaphor, simile, symbolism, irony, allegory, allusion, imagery",
      criticism: "Formalist, historical, psychological, feminist, postcolonial, reader-response"
    }
  },
  philosophy: {
    branches: {
      metaphysics: "Reality, existence, causation, free will, mind-body problem",
      epistemology: "Knowledge, truth, justification, skepticism, rationalism vs empiricism",
      ethics: "Normative theories, metaethics, applied ethics, moral psychology",
      logic: "Deductive, inductive, formal, informal, fallacies, critical thinking",
      aesthetics: "Beauty, art, taste, criticism, philosophy of art"
    },
    traditions: {
      western: "Ancient, medieval, modern, contemporary, analytic, continental",
      eastern: "Confucianism, Taoism, Buddhism, Hinduism, comparative philosophy"
    }
  },
  studyStrategies: {
    learning: {
      active: "Elaboration, self-explanation, teaching others, practice testing",
      metacognitive: "Planning, monitoring, evaluating, self-regulation",
      collaborative: "Group study, peer teaching, discussion, project-based learning"
    },
    memory: {
      encoding: "Elaborative, semantic, dual coding, organization, mnemonics",
      retention: "Spaced repetition, interleaving, varied practice, sleep consolidation",
      retrieval: "Testing effect, generation effect, retrieval cues, context-dependent"
    },
    skills: {
      reading: "SQ3R, annotation, summarization, critical reading, speed reading",
      writing: "Planning, drafting, revising, editing, academic writing conventions",
      problemSolving: "Understanding, planning, executing, checking, pattern recognition",
      timeManagement: "Prioritization, scheduling, goal-setting, avoiding procrastination"
    }
  }
};

export function getDetailedExplanation(topic: string, subtopic?: string): string {
  // This function provides detailed explanations based on the knowledge base
  const topicLower = topic.toLowerCase();
  
  // Search through knowledge base for matching content
  for (const [category, content] of Object.entries(comprehensiveKnowledgeBase)) {
    if (topicLower.includes(category) || category.includes(topicLower)) {
      if (subtopic) {
        for (const [sub, details] of Object.entries(content as any)) {
          if (subtopic.toLowerCase().includes(sub) || sub.includes(subtopic.toLowerCase())) {
            return `**${category.charAt(0).toUpperCase() + category.slice(1)} - ${sub.charAt(0).toUpperCase() + sub.slice(1)}:**\n\n${details}`;
          }
        }
      }
      return `**${category.charAt(0).toUpperCase() + category.slice(1)} Overview:**\n\n${JSON.stringify(content, null, 2).replace(/[{}"]/g, '').replace(/,\n/g, '\n')}`;
    }
  }
  
  return "I can help you with that topic! Please be more specific about what aspect you'd like to explore.";
}