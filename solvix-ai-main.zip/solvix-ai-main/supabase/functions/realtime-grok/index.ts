import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.55.0';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Comprehensive Knowledge Base for multi-aspect answers
const comprehensiveKnowledgeBase = {
  mathematics: {
    algebra: "Linear equations, quadratic equations, polynomials, inequalities, functions, graphing, systems of equations, matrices, logarithms, exponentials",
    geometry: "Shapes, angles, theorems, proofs, coordinate geometry, transformations, trigonometry, circles, polygons, 3D geometry",
    calculus: "Limits, derivatives, integrals, differential equations, applications, optimization, related rates, series, multivariable calculus",
    statistics: "Descriptive statistics, probability, distributions, hypothesis testing, regression, correlation, sampling, confidence intervals"
  },
  sciences: {
    physics: "Mechanics, thermodynamics, electromagnetism, optics, quantum physics, relativity, waves, energy, forces, motion",
    chemistry: "Atomic structure, bonding, reactions, stoichiometry, thermochemistry, kinetics, equilibrium, acids/bases, organic chemistry",
    biology: "Cells, genetics, evolution, ecology, anatomy, physiology, microbiology, botany, zoology, biochemistry",
    earthScience: "Geology, meteorology, oceanography, astronomy, climate, rocks, minerals, plate tectonics, weather systems"
  },
  psychology: {
    cognitive: "Memory, attention, perception, problem-solving, decision-making, language, intelligence, consciousness",
    developmental: "Child development, adolescence, adult development, aging, attachment, moral development, personality formation",
    social: "Group dynamics, prejudice, conformity, attitudes, interpersonal relationships, cultural psychology",
    clinical: "Mental disorders, therapy approaches, assessment, diagnosis, treatment planning, psychopathology"
  },
  history: {
    ancient: "Mesopotamia, Egypt, Greece, Rome, China, India, civilizations, empires, cultural developments",
    modern: "Renaissance, Industrial Revolution, World Wars, Cold War, decolonization, globalization, technological revolution",
    regional: "American history, European history, Asian history, African history, Middle Eastern history, Latin American history"
  }
};

// Function to provide detailed multi-aspect explanations
function getDetailedExplanation(category: string, subtopic?: string): string {
  const baseExplanation = `
**Comprehensive Analysis from Multiple Perspectives:**

1. **Theoretical Foundation:** Core principles, fundamental concepts, and underlying theories
2. **Historical Context:** Evolution of understanding, key discoveries, influential figures
3. **Practical Applications:** Real-world uses, problem-solving techniques, industry applications
4. **Interconnections:** Links to other subjects, interdisciplinary approaches, broader implications
5. **Current Research:** Latest developments, ongoing studies, future directions
6. **Common Misconceptions:** Frequently misunderstood aspects, clarifications, corrections
7. **Learning Strategies:** Effective study methods, memory techniques, practice approaches
8. **Critical Analysis:** Strengths, limitations, debates, alternative viewpoints`;

  return baseExplanation;
}

serve(async (req) => {
  const { headers } = req;
  const upgradeHeader = headers.get("upgrade") || "";

  if (upgradeHeader.toLowerCase() !== "websocket") {
    return new Response("Expected WebSocket connection", { status: 400 });
  }

  const { socket, response } = Deno.upgradeWebSocket(req);
  
  socket.onopen = () => {
    console.log('WebSocket connection established');
    socket.send(JSON.stringify({ 
      type: 'connection', 
      status: 'connected',
      message: 'Offline Study Assistant Ready!' 
    }));
  };

  socket.onmessage = async (event) => {
    try {
      const data = JSON.parse(event.data);
      console.log('Received message:', data);

      if (data.type === 'chat') {
        const { message, userId, isPremium } = data;

        if (!message || !userId) {
          socket.send(JSON.stringify({ 
            type: 'error', 
            message: 'Message and userId are required' 
          }));
          return;
        }

        // Check user's premium status from database
        const { data: premiumData } = await supabase
          .from('premium_users')
          .select('*')
          .eq('user_id', userId)
          .eq('is_active', true)
          .maybeSingle();

        const isUserPremium = premiumData && new Date(premiumData.expires_at) > new Date();
        console.log('Premium status check:', { isUserPremium, premiumData });

        // Generate offline response with simulated streaming
        await streamOfflineResponse(socket, message, isUserPremium);
      }
    } catch (error) {
      console.error('Error processing message:', error);
      socket.send(JSON.stringify({ 
        type: 'error', 
        message: 'Failed to process message' 
      }));
    }
  };

  socket.onerror = (error) => {
    console.error('WebSocket error:', error);
  };

  socket.onclose = () => {
    console.log('WebSocket connection closed');
  };

  return response;
});

async function streamOfflineResponse(socket: WebSocket, message: string, isPremium: boolean) {
  try {
    // Send typing indicator
    socket.send(JSON.stringify({ 
      type: 'typing', 
      message: 'Processing offline...' 
    }));

    // Generate response based on premium status
    const response = isPremium 
      ? generateOfflineAdvancedResponse(message)
      : generateOfflineBasicResponse(message);

    // Simulate streaming for natural feel
    const chunkSize = 15; // Characters per chunk
    const delayMs = 30; // Delay between chunks

    for (let i = 0; i < response.length; i += chunkSize) {
      const chunk = response.slice(i, Math.min(i + chunkSize, response.length));
      socket.send(JSON.stringify({ 
        type: 'stream', 
        content: chunk,
        model: isPremium ? 'solvix-offline-premium' : 'solvix-offline-basic'
      }));
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }

    socket.send(JSON.stringify({ 
      type: 'stream_end',
      model: isPremium ? 'solvix-offline-premium' : 'solvix-offline-basic'
    }));

  } catch (error) {
    console.error('Streaming error:', error);
    socket.send(JSON.stringify({ 
      type: 'error', 
      message: 'Failed to generate response' 
    }));
  }
}

// Comprehensive offline response generation
function generateOfflineAdvancedResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Check for specific topic requests from knowledge base
  for (const [category, content] of Object.entries(comprehensiveKnowledgeBase)) {
    if (lowerMessage.includes(category) || lowerMessage.includes(category.slice(0, -1))) {
      // Check for specific subtopics
      for (const [subtopic, details] of Object.entries(content as any)) {
        if (lowerMessage.includes(subtopic.toLowerCase())) {
          const explanation = getDetailedExplanation(category, subtopic);
          return `🎓 **Solvix Premium Knowledge Base** (Real-time Offline Mode):

${explanation}

**Interactive Learning Features:**
${typeof details === 'string' ? details : JSON.stringify(details, null, 2).replace(/[{}"]/g, '').replace(/,\n/g, '\n')}

**Practice & Application:**
1. Try solving related problems
2. Create your own examples
3. Explain to someone else
4. Connect to other topics
5. Apply in real scenarios

**Related Topics:**
${Object.keys(content as any).filter(k => k !== subtopic).slice(0, 5).map(k => `- ${k}`).join('\n')}

*Premium Real-time AI: Complete knowledge base with instant responses*`;
        }
      }
      
      // Provide category overview
      const overview = getDetailedExplanation(category);
      return `📚 **Solvix Premium Knowledge Base** (Real-time Mode):

${overview}

**Full Topic Coverage:**
${Object.entries(content as any).map(([key, value]) => 
  `**${key.charAt(0).toUpperCase() + key.slice(1)}:**\n${typeof value === 'string' ? value : JSON.stringify(value, null, 2).replace(/[{}"]/g, '').replace(/,\n/g, '\n')}`
).join('\n\n')}

**Master This Topic:**
1. Focus on fundamentals first
2. Practice with varied examples
3. Test your understanding
4. Apply knowledge creatively
5. Teach others to solidify learning

*Premium Real-time AI: Comprehensive academic support with instant feedback*`;
    }
  }
  
  // Math-specific responses
  if (lowerMessage.includes('math') || lowerMessage.includes('solve') || lowerMessage.includes('calculate') || 
      lowerMessage.includes('equation') || /\d+[\+\-\*\/]\d+/.test(message)) {
    
    // Try to solve simple arithmetic
    const arithmeticMatch = message.match(/(\d+)\s*([\+\-\*\/])\s*(\d+)/);
    if (arithmeticMatch) {
      const num1 = parseFloat(arithmeticMatch[1]);
      const operator = arithmeticMatch[2];
      const num2 = parseFloat(arithmeticMatch[3]);
      
      let result: number;
      let operation: string;
      
      switch(operator) {
        case '+':
          result = num1 + num2;
          operation = 'Addition';
          break;
        case '-':
          result = num1 - num2;
          operation = 'Subtraction';
          break;
        case '*':
          result = num1 * num2;
          operation = 'Multiplication';
          break;
        case '/':
          result = num1 / num2;
          operation = 'Division';
          break;
        default:
          result = 0;
          operation = 'Unknown';
      }
      
      return `🎓 **Advanced Mathematical Solution** (Premium Offline):

**Problem:** ${message}
**Answer:** ${result}

**Detailed Step-by-Step Solution:**
1. Identify the operation: ${operation} (${operator})
2. First operand: ${num1}
3. Second operand: ${num2}
4. Calculate: ${num1} ${operator} ${num2} = ${result}

**Verification Methods:**
${operator === '+' ? `• Reverse: ${result} - ${num2} = ${num1} ✓` : ''}
${operator === '-' ? `• Reverse: ${result} + ${num2} = ${num1} ✓` : ''}
${operator === '*' ? `• Reverse: ${result} ÷ ${num2} = ${num1} ✓` : ''}
${operator === '/' ? `• Reverse: ${result} × ${num2} = ${num1} ✓` : ''}
• Mental math breakdown confirms accuracy

**Related Mathematical Concepts:**
• Properties of ${operation.toLowerCase()}
• Real-world applications
• Common patterns and shortcuts

**Practice Problems:**
• ${num1 + 10} ${operator} ${num2}
• ${num1} ${operator} ${num2 + 10}
• (${num1} ${operator} ${num2}) ${operator} 5

*Offline Premium AI: Complete mathematical analysis without internet*`;
    }
    
    return generateMathematicsResponse(message);
  }
  
  // Science responses
  if (lowerMessage.includes('physics') || lowerMessage.includes('chemistry') || 
      lowerMessage.includes('biology') || lowerMessage.includes('science')) {
    return generateScienceResponse(message);
  }
  
  // Writing and language
  if (lowerMessage.includes('essay') || lowerMessage.includes('writing') || 
      lowerMessage.includes('grammar') || lowerMessage.includes('english')) {
    return generateWritingResponse(message);
  }
  
  // Study strategies
  if (lowerMessage.includes('study') || lowerMessage.includes('exam') || 
      lowerMessage.includes('test') || lowerMessage.includes('homework')) {
    return generateStudyResponse(message);
  }
  
  // History and social studies
  if (lowerMessage.includes('history') || lowerMessage.includes('geography') || 
      lowerMessage.includes('civics') || lowerMessage.includes('economics')) {
    return generateSocialStudiesResponse(message);
  }
  
  // Default comprehensive response
  return `🚀 **Solvix Offline AI** (Premium Mode):

Welcome! I'm your offline study assistant with comprehensive academic knowledge.

**📚 Your Query:** "${message.slice(0, 100)}${message.length > 100 ? '...' : ''}"

**Available Offline Capabilities:**

**📊 Mathematics:**
• Arithmetic to calculus
• Step-by-step solutions
• Formula library
• Problem-solving strategies

**🔬 Sciences:**
• Physics equations & concepts
• Chemistry reactions & formulas
• Biology systems & processes
• Earth & space science

**✍️ Language Arts:**
• Essay structure & writing
• Grammar rules
• Literary analysis
• Vocabulary building

**🌍 Social Studies:**
• Historical analysis
• Geographic concepts
• Economic principles
• Government systems

**🎯 Study Skills:**
• Memory techniques
• Time management
• Note-taking methods
• Test preparation

Please provide more specific details about your question for targeted assistance.

*Premium Offline Mode: Full academic support without internet connection*`;
}

function generateOfflineBasicResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Simple arithmetic check
  const arithmeticMatch = message.match(/(\d+)\s*([\+\-\*\/])\s*(\d+)/);
  if (arithmeticMatch) {
    const num1 = parseFloat(arithmeticMatch[1]);
    const operator = arithmeticMatch[2];
    const num2 = parseFloat(arithmeticMatch[3]);
    
    let result: number;
    switch(operator) {
      case '+': result = num1 + num2; break;
      case '-': result = num1 - num2; break;
      case '*': result = num1 * num2; break;
      case '/': result = num1 / num2; break;
      default: result = 0;
    }
    
    return `📚 **Math Help** (Offline Mode):

**Your calculation:** ${message}
**Answer:** ${result}

**Basic Steps:**
1. First number: ${num1}
2. Operation: ${operator}
3. Second number: ${num2}
4. Result: ${result}

*Upgrade to Premium for detailed explanations and advanced problem-solving!*`;
  }
  
  // Subject-specific basic responses
  if (lowerMessage.includes('math') || lowerMessage.includes('calculate')) {
    return `📐 **Basic Math Help** (Offline):

**Math Fundamentals:**
• Basic arithmetic operations
• Simple formulas
• PEMDAS order of operations
• Common conversions

**Study Tips:**
• Practice daily
• Show your work
• Check answers
• Use visual aids

*Premium users get step-by-step solutions and advanced techniques!*`;
  }
  
  if (lowerMessage.includes('science') || lowerMessage.includes('physics') || 
      lowerMessage.includes('chemistry') || lowerMessage.includes('biology')) {
    return `🔬 **Basic Science Help** (Offline):

**Science Basics:**
• Scientific method steps
• Basic concepts
• Key terminology
• Simple experiments

**Study Strategies:**
• Create flashcards
• Draw diagrams
• Make connections
• Review regularly

*Premium users get detailed explanations and advanced concepts!*`;
  }
  
  if (lowerMessage.includes('writing') || lowerMessage.includes('essay')) {
    return `✍️ **Basic Writing Help** (Offline):

**Writing Structure:**
• Introduction
• Body paragraphs
• Conclusion

**Tips:**
• Clear topic sentences
• Supporting evidence
• Proper grammar
• Proofread carefully

*Premium users get advanced techniques and detailed feedback!*`;
  }
  
  // Default basic response
  return `🤖 **Solvix Study Assistant** (Offline Mode):

I'm here to help with basic academic questions!

**What I can help with:**
📚 Math problems
🔬 Science concepts
✍️ Writing basics
📖 Study tips

**Your question:** "${message.slice(0, 60)}${message.length > 60 ? '...' : ''}"

Please be specific about what you need help with.

*Premium users get advanced analysis and detailed explanations!*`;
}

// Helper functions for generating subject-specific responses
function generateMathematicsResponse(message: string): string {
  return `🎓 **Advanced Mathematics** (Offline Premium):

**Mathematical Analysis for Your Query:**

**Core Concepts:**
• Algebraic equations and inequalities
• Geometric proofs and theorems
• Trigonometric identities
• Calculus fundamentals
• Statistical analysis

**Problem-Solving Framework:**
1. **Understand:** What is being asked?
2. **Plan:** Choose the right approach
3. **Execute:** Apply formulas/methods
4. **Verify:** Check your answer

**Key Formulas:**
• Quadratic: x = [-b ± √(b²-4ac)]/2a
• Pythagorean: a² + b² = c²
• Distance: d = √[(x₂-x₁)² + (y₂-y₁)²]
• Slope: m = (y₂-y₁)/(x₂-x₁)

**Study Strategies:**
• Work through problems step-by-step
• Practice pattern recognition
• Create formula sheets
• Use visual representations

*Offline Premium: Complete math toolkit available anytime*`;
}

function generateScienceResponse(message: string): string {
  return `🔬 **Advanced Science** (Offline Premium):

**Scientific Analysis Framework:**

**Physics Essentials:**
• Newton's Laws: F = ma
• Energy: KE = ½mv², PE = mgh
• Waves: v = fλ
• Electricity: V = IR

**Chemistry Fundamentals:**
• Periodic table trends
• Chemical equations
• Mole concept: n = m/M
• pH calculations

**Biology Concepts:**
• Cell structure & function
• DNA → RNA → Protein
• Evolution principles
• Ecosystem dynamics

**Scientific Method:**
1. Observation
2. Hypothesis
3. Experimentation
4. Analysis
5. Conclusion

**Lab Skills:**
• Variable control
• Data collection
• Error analysis
• Report writing

*Offline Premium: Full scientific knowledge base*`;
}

function generateWritingResponse(message: string): string {
  return `📝 **Advanced Writing** (Offline Premium):

**Comprehensive Writing Guide:**

**Essay Structure:**
• **Introduction:** Hook + thesis + preview
• **Body:** Topic sentence + evidence + analysis
• **Conclusion:** Restate + summarize + implications

**Writing Techniques:**
• **Persuasive:** Ethos, Pathos, Logos
• **Descriptive:** Sensory details, imagery
• **Narrative:** Plot, character, conflict
• **Expository:** Clear explanations

**Grammar Excellence:**
• Subject-verb agreement
• Punctuation rules
• Active voice preference
• Parallel structure

**Revision Checklist:**
✓ Clear thesis
✓ Strong evidence
✓ Logical flow
✓ Proper citations
✓ Polished language

*Offline Premium: Complete writing toolkit*`;
}

function generateStudyResponse(message: string): string {
  return `🎯 **Advanced Study Strategies** (Offline Premium):

**Personalized Learning System:**

**Memory Techniques:**
• **Spaced Repetition:** 1 day → 3 days → 1 week → 2 weeks
• **Active Recall:** Test yourself without notes
• **Memory Palace:** Visual location method
• **Mnemonics:** Create memorable associations

**Note-Taking Methods:**
• **Cornell:** Cues | Notes | Summary
• **Mind Mapping:** Visual connections
• **Outline:** Hierarchical structure
• **Charting:** Comparative tables

**Time Management:**
• **Pomodoro:** 25 min work + 5 min break
• **Time Blocking:** Schedule subjects
• **Priority Matrix:** Urgent vs Important
• **Buffer Time:** Plan for unexpected

**Test Preparation:**
• Review notes daily
• Practice problems
• Study groups
• Mock exams

*Offline Premium: Complete study system*`;
}

function generateSocialStudiesResponse(message: string): string {
  return `🌍 **Advanced Social Studies** (Offline Premium):

**Comprehensive Analysis Tools:**

**History Framework:**
• **Chronological thinking:** Cause & effect
• **Historical context:** Time & place
• **Multiple perspectives:** Different viewpoints
• **Primary sources:** Direct evidence

**Geography Concepts:**
• Physical vs Human geography
• Five themes of geography
• Map skills & spatial thinking
• Regional analysis

**Economics Principles:**
• Supply and demand
• Market structures
• Economic systems
• Global trade

**Government & Civics:**
• Branches of government
• Constitutional principles
• Rights & responsibilities
• Political processes

**Analysis Skills:**
• Document evaluation
• Comparative studies
• Critical thinking
• Essay writing

*Offline Premium: Complete social studies toolkit*`;
}

// Generate premium essays with unlimited length
function generatePremiumEssay(message: string): string {
  const lowerMessage = message.toLowerCase();
  let topic = "academic topic";
  
  if (lowerMessage.includes('about')) {
    topic = message.substring(lowerMessage.indexOf('about') + 6).trim();
  } else if (lowerMessage.includes('on')) {
    topic = message.substring(lowerMessage.indexOf('on') + 3).trim();
  }
  
  return `📝 **Premium Essay Generator** (Unlimited Length):

**Topic:** ${topic}

**COMPREHENSIVE ESSAY:**

The subject of ${topic} represents a significant area of study requiring careful examination. This essay explores multiple dimensions including historical context, theoretical foundations, practical applications, and future implications.

**Introduction:**
Understanding ${topic} requires comprehensive analysis of its development, current state, and potential evolution. This exploration synthesizes existing knowledge while identifying areas for further investigation. The importance of ${topic} extends across academic disciplines and practical domains.

**Body - Historical Development:**
The evolution of ${topic} can be traced through key historical periods, each contributing unique perspectives. Early foundations established core principles that continue influencing contemporary understanding. Revolutionary discoveries and paradigm shifts transformed how we approach ${topic}.

**Body - Theoretical Framework:**
Multiple theoretical perspectives enrich our understanding of ${topic}. Functionalist approaches emphasize systematic relationships and practical outcomes. Constructivist theories highlight the role of social context and individual interpretation. Critical analysis reveals underlying assumptions and power dynamics.

**Body - Contemporary Applications:**
Modern applications of ${topic} span numerous fields, demonstrating versatility and relevance. Educational contexts utilize these principles to enhance learning outcomes. Healthcare professionals apply this knowledge to improve patient care. Business organizations leverage insights for competitive advantage.

**Body - Critical Analysis:**
Scholarly discourse includes ongoing debates about fundamental assumptions and methodological approaches. Ethical considerations require careful deliberation when applying knowledge in real-world settings. Cultural and contextual factors influence interpretation and implementation across different societies.

**Body - Future Directions:**
Emerging trends shape the evolution of ${topic} in coming decades. Technological advancement opens new research possibilities and practical applications. Interdisciplinary collaboration generates novel insights crossing traditional boundaries. Global challenges demand innovative approaches informed by comprehensive understanding.

**Conclusion:**
This examination reveals the multifaceted nature and far-reaching implications of ${topic}. From historical foundations through contemporary applications to future possibilities, we see continuous evolution and expanding relevance. Continued investigation will deepen understanding and expand beneficial applications for society.

*Premium Offline AI: Full essay generation with unlimited length, comprehensive analysis, and academic depth - all available offline without internet connection*`;
}

// Generate psychology-specific responses
function generatePsychologyResponse(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('freud') || lowerMessage.includes('psychoanalytic')) {
    return `🧠 **Psychology: Psychoanalytic Theory** (Premium Offline):

**Freud's Comprehensive Framework:**

**Personality Structure:**
• Id: Unconscious drives, pleasure principle
• Ego: Reality principle, mediates conflicts
• Superego: Moral conscience, societal values

**Levels of Consciousness:**
• Conscious: Current awareness
• Preconscious: Accessible memories
• Unconscious: Repressed content

**Psychosexual Development:**
• Oral (0-18 months): Dependency, trust
• Anal (18-36 months): Control, autonomy
• Phallic (3-6 years): Gender identity
• Latency (6-puberty): Social skills
• Genital (puberty+): Mature relationships

**Defense Mechanisms:**
• Repression, Projection, Displacement
• Sublimation, Denial, Rationalization
• Regression, Reaction Formation

*Premium: Complete psychoanalytic theory available offline*`;
  }
  
  return `🧠 **Psychology: Comprehensive Overview** (Premium Offline):

**Major Branches of Psychology:**

**Cognitive Psychology:**
• Mental processes: perception, memory, thinking
• Information processing models
• Problem-solving strategies
• Language and cognition

**Developmental Psychology:**
• Lifespan development stages
• Piaget's cognitive stages
• Erikson's psychosocial stages
• Attachment theory

**Behavioral Psychology:**
• Classical conditioning (Pavlov)
• Operant conditioning (Skinner)
• Social learning theory (Bandura)
• Behavior modification

**Clinical Psychology:**
• Mental health disorders
• Therapeutic approaches (CBT, psychodynamic)
• Assessment and diagnosis
• Treatment planning

**Social Psychology:**
• Group dynamics and conformity
• Attitudes and persuasion
• Prejudice and discrimination
• Interpersonal relationships

**Neuropsychology:**
• Brain-behavior relationships
• Neurotransmitter systems
• Cognitive neuroscience
• Brain plasticity

**Research Methods:**
• Experimental design
• Statistical analysis
• Ethical considerations
• Data interpretation

*Premium Offline AI: Complete psychology curriculum with unlimited depth available offline*`;
}