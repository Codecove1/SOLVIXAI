-- Update the function to remove voice and image features from premium features list
CREATE OR REPLACE FUNCTION public.get_premium_features(user_uuid UUID)
RETURNS TABLE(
  has_premium BOOLEAN,
  expires_at TIMESTAMPTZ,
  features JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE WHEN pu.expires_at > now() THEN true ELSE false END as has_premium,
    pu.expires_at,
    CASE 
      WHEN pu.expires_at > now() THEN 
        jsonb_build_object(
          'unlimited_essays', true,
          'advanced_math', true,
          'psychology_support', true,
          'detailed_explanations', true,
          'comprehensive_knowledge_base', true,
          'priority_support', true,
          'offline_mode', true,
          'realtime_assistance', true
        )
      ELSE 
        jsonb_build_object(
          'unlimited_essays', false,
          'advanced_math', false,
          'psychology_support', false,
          'detailed_explanations', false,
          'comprehensive_knowledge_base', false,
          'priority_support', false,
          'offline_mode', false,
          'realtime_assistance', false
        )
    END as features
  FROM public.premium_users pu
  WHERE pu.user_id = user_uuid
  AND pu.is_active = true
  ORDER BY pu.expires_at DESC
  LIMIT 1;
  
  -- Return default if no premium record found
  IF NOT FOUND THEN
    RETURN QUERY
    SELECT 
      false as has_premium,
      NULL::TIMESTAMPTZ as expires_at,
      jsonb_build_object(
        'unlimited_essays', false,
        'advanced_math', false,
        'psychology_support', false,
        'detailed_explanations', false,
        'comprehensive_knowledge_base', false,
        'priority_support', false,
        'offline_mode', false,
        'realtime_assistance', false
      ) as features;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.get_premium_features TO authenticated;