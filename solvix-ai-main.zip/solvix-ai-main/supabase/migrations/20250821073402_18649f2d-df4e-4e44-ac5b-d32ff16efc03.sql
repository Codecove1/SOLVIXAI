-- Create user_messages table for creator-user communication
CREATE TABLE public.user_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  username text NOT NULL,
  message text NOT NULL,
  is_premium boolean NOT NULL DEFAULT false,
  reply text,
  replied_at timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.user_messages ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own messages" 
ON public.user_messages 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own messages" 
ON public.user_messages 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Create policies for creator access (admins can view and update all messages)
CREATE POLICY "Admins can view all messages" 
ON public.user_messages 
FOR SELECT 
USING ((auth.jwt() ->> 'email'::text) = ANY (ARRAY['codecove7@gmail.com'::text, 'xfan5193@gmail.com'::text, 'x483481@gmail.com'::text]));

CREATE POLICY "Admins can update messages" 
ON public.user_messages 
FOR UPDATE 
USING ((auth.jwt() ->> 'email'::text) = ANY (ARRAY['codecove7@gmail.com'::text, 'xfan5193@gmail.com'::text, 'x483481@gmail.com'::text]));

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_user_messages_updated_at
BEFORE UPDATE ON public.user_messages
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Enable real-time for the table
ALTER TABLE public.user_messages REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_messages;