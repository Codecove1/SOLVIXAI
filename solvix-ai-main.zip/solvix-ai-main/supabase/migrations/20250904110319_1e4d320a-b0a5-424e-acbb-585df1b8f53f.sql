-- Create function to automatically activate premium features when request is approved
CREATE OR REPLACE FUNCTION public.activate_premium_on_approval()
RETURNS TRIGGER AS $$
BEGIN
  -- Check if status changed from pending to approved
  IF OLD.status = 'pending' AND NEW.status = 'approved' THEN
    -- Check if user already has active premium
    IF NOT EXISTS (
      SELECT 1 FROM public.premium_users 
      WHERE user_id = NEW.user_id 
      AND is_active = true 
      AND expires_at > now()
    ) THEN
      -- Insert new premium user record with 30-day subscription
      INSERT INTO public.premium_users (
        user_id,
        username,
        expires_at,
        is_active,
        granted_by,
        activated_at
      ) VALUES (
        NEW.user_id,
        NEW.username,
        now() + interval '30 days',
        true,
        auth.uid(), -- The admin who approved it
        now()
      );
    ELSE
      -- Extend existing premium subscription by 30 days
      UPDATE public.premium_users
      SET 
        expires_at = GREATEST(expires_at, now()) + interval '30 days',
        is_active = true,
        granted_by = auth.uid()
      WHERE user_id = NEW.user_id;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to activate premium on approval
CREATE TRIGGER activate_premium_on_approval_trigger
AFTER UPDATE ON public.subscription_requests
FOR EACH ROW
EXECUTE FUNCTION public.activate_premium_on_approval();

-- Create function to check and return all premium features status
CREATE OR REPLACE FUNCTION public.get_premium_features(user_uuid UUID)
RETURNS TABLE(
  has_premium BOOLEAN,
  expires_at TIMESTAMPTZ,
  features JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    CASE WHEN pu.expires_at > now() THEN true ELSE false END as has_premium,
    pu.expires_at,
    CASE 
      WHEN pu.expires_at > now() THEN 
        jsonb_build_object(
          'unlimited_essays', true,
          'advanced_math', true,
          'psychology_support', true,
          'voice_input', true,
          'image_analysis', true,
          'detailed_explanations', true,
          'comprehensive_knowledge_base', true,
          'priority_support', true,
          'offline_mode', true,
          'realtime_assistance', true
        )
      ELSE 
        jsonb_build_object(
          'unlimited_essays', false,
          'advanced_math', false,
          'psychology_support', false,
          'voice_input', false,
          'image_analysis', false,
          'detailed_explanations', false,
          'comprehensive_knowledge_base', false,
          'priority_support', false,
          'offline_mode', false,
          'realtime_assistance', false
        )
    END as features
  FROM public.premium_users pu
  WHERE pu.user_id = user_uuid
  AND pu.is_active = true
  ORDER BY pu.expires_at DESC
  LIMIT 1;
  
  -- Return default if no premium record found
  IF NOT FOUND THEN
    RETURN QUERY
    SELECT 
      false as has_premium,
      NULL::TIMESTAMPTZ as expires_at,
      jsonb_build_object(
        'unlimited_essays', false,
        'advanced_math', false,
        'psychology_support', false,
        'voice_input', false,
        'image_analysis', false,
        'detailed_explanations', false,
        'comprehensive_knowledge_base', false,
        'priority_support', false,
        'offline_mode', false,
        'realtime_assistance', false
      ) as features;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION public.get_premium_features TO authenticated;