import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';

export const useSupabasePremium = () => {
  const [isPremium, setIsPremium] = useState(false);
  const [premiumExpiry, setPremiumExpiry] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    if (!user) {
      setIsPremium(false);
      setPremiumExpiry(null);
      setLoading(false);
      return;
    }

    const checkPremiumStatus = async () => {
      try {
        const { data, error } = await supabase
          .from('premium_users')
          .select('*')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .maybeSingle();

        if (error) {
          console.error('Error checking premium status:', error);
          setIsPremium(false);
          setPremiumExpiry(null);
        } else if (data) {
          const expiryDate = new Date(data.expires_at);
          const now = new Date();
          
          if (expiryDate > now) {
            setIsPremium(true);
            setPremiumExpiry(expiryDate);
          } else {
            setIsPremium(false);
            setPremiumExpiry(null);
          }
        } else {
          setIsPremium(false);
          setPremiumExpiry(null);
        }
      } catch (error) {
        console.error('Error checking premium status:', error);
        setIsPremium(false);
        setPremiumExpiry(null);
      }
      
      setLoading(false);
    };

    checkPremiumStatus();
    
    // Check every minute for expiry
    const interval = setInterval(checkPremiumStatus, 60000);
    
    return () => clearInterval(interval);
  }, [user]);

  return { isPremium, premiumExpiry, loading };
};