import { useState, useEffect } from 'react';

interface PremiumUser {
  username: string;
  activatedAt: string;
  expiresAt: string;
}

export const usePremiumStatus = (username?: string) => {
  const [isPremium, setIsPremium] = useState(false);
  const [premiumExpiry, setPremiumExpiry] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!username) {
      setLoading(false);
      return;
    }

    const checkPremiumStatus = () => {
      const premiumUsers: PremiumUser[] = JSON.parse(localStorage.getItem('premiumUsers') || '[]');
      const userPremium = premiumUsers.find(user => user.username === username);
      
      if (userPremium) {
        const expiryDate = new Date(userPremium.expiresAt);
        const now = new Date();
        
        if (expiryDate > now) {
          setIsPremium(true);
          setPremiumExpiry(expiryDate);
        } else {
          setIsPremium(false);
          setPremiumExpiry(null);
        }
      } else {
        setIsPremium(false);
        setPremiumExpiry(null);
      }
      
      setLoading(false);
    };

    checkPremiumStatus();
    
    // Check every minute for expiry
    const interval = setInterval(checkPremiumStatus, 60000);
    
    return () => clearInterval(interval);
  }, [username]);

  return { isPremium, premiumExpiry, loading };
};