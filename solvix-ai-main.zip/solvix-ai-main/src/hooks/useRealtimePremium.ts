import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './useAuth';
import { useToast } from './use-toast';

export const useRealtimePremium = () => {
  const [isPremium, setIsPremium] = useState(false);
  const [premiumExpiry, setPremiumExpiry] = useState<Date | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) {
      setIsPremium(false);
      setPremiumExpiry(null);
      setLoading(false);
      return;
    }

    const checkPremiumStatus = async () => {
      try {
        const { data, error } = await supabase
          .from('premium_users')
          .select('*')
          .eq('user_id', user.id)
          .eq('is_active', true)
          .maybeSingle();

        if (error) {
          console.error('Error checking premium status:', error);
          setIsPremium(false);
          setPremiumExpiry(null);
        } else if (data) {
          const expiryDate = new Date(data.expires_at);
          const now = new Date();
          
          if (expiryDate > now) {
            setIsPremium(true);
            setPremiumExpiry(expiryDate);
          } else {
            setIsPremium(false);
            setPremiumExpiry(null);
          }
        } else {
          setIsPremium(false);
          setPremiumExpiry(null);
        }
      } catch (error) {
        console.error('Error checking premium status:', error);
        setIsPremium(false);
        setPremiumExpiry(null);
      }
      
      setLoading(false);
    };

    checkPremiumStatus();
    
    // Set up real-time subscription for premium status changes
    const channel = supabase
      .channel('premium-status-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'premium_users',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Premium status changed:', payload);
          
          if (payload.eventType === 'INSERT' || payload.eventType === 'UPDATE') {
            const newData = payload.new;
            if (newData?.is_active) {
              const expiryDate = new Date(newData.expires_at);
              const now = new Date();
              
              if (expiryDate > now) {
                const wasPremium = isPremium;
                setIsPremium(true);
                setPremiumExpiry(expiryDate);
                
                if (!wasPremium) {
                  toast({
                    title: "🎉 Premium Activated!",
                    description: "Your premium access has been granted. Enjoy all premium features!",
                  });
                }
              }
            } else {
              setIsPremium(false);
              setPremiumExpiry(null);
              
              if (isPremium) {
                toast({
                  title: "Premium Status Changed",
                  description: "Your premium access has been updated.",
                });
              }
            }
          } else if (payload.eventType === 'DELETE') {
            setIsPremium(false);
            setPremiumExpiry(null);
            
            toast({
              title: "Premium Access Removed",
              description: "Your premium access has been removed.",
              variant: "destructive"
            });
          }
        }
      )
      .subscribe();
    
    // Check every minute for expiry
    const interval = setInterval(checkPremiumStatus, 60000);
    
    return () => {
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, [user, toast, isPremium]);

  return { isPremium, premiumExpiry, loading };
};