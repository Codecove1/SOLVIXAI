import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, XCircle, Users, Clock, DollarSign, ArrowLeft, LogOut, ToggleLeft, ToggleRight, MessageSquare, Send, User } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface SubscriptionRequest {
  id: string;
  username: string;
  user_id: string;
  created_at: string;
  status: 'pending' | 'approved' | 'denied';
}

interface PremiumUser {
  id: string;
  username: string;
  user_id: string;
  activated_at: string;
  expires_at: string;
  is_active: boolean;
}

interface UserMessage {
  id: string;
  user_id: string;
  username: string;
  message: string;
  is_premium: boolean;
  reply?: string;
  replied_at?: string;
  created_at: string;
}

export default function CreatorPage() {
  const [subscriptionRequests, setSubscriptionRequests] = useState<SubscriptionRequest[]>([]);
  const [premiumUsers, setPremiumUsers] = useState<PremiumUser[]>([]);
  const [userMessages, setUserMessages] = useState<UserMessage[]>([]);
  const [replyText, setReplyText] = useState<{ [key: string]: string }>({});
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user, isAuthorized, signOut } = useAuth();

  useEffect(() => {
    if (isAuthorized) {
      loadData();
      
      // Set up real-time subscriptions
      const subscriptionRequestsChannel = supabase
        .channel('subscription-requests-changes')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'subscription_requests'
          },
          (payload) => {
            console.log('New subscription request:', payload);
            toast({
              title: "New Subscription Request!",
              description: `${payload.new?.username} has requested premium access.`,
            });
            loadData();
          }
        )
        .subscribe();

      const messagesChannel = supabase
        .channel('user-messages-changes')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'user_messages'
          },
          (payload) => {
            console.log('New message received:', payload);
            toast({
              title: "New Message!",
              description: `New message from ${payload.new?.username}`,
            });
            loadData();
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(subscriptionRequestsChannel);
        supabase.removeChannel(messagesChannel);
      };
    }
  }, [isAuthorized, toast]);

  const loadData = async () => {
    try {
      const [requestsData, premiumData, messagesData] = await Promise.all([
        supabase.from('subscription_requests').select('*').order('created_at', { ascending: false }),
        supabase.from('premium_users').select('*').order('created_at', { ascending: false }),
        supabase.from('user_messages' as any).select('*').order('created_at', { ascending: false })
      ]);

      if (requestsData.error) throw requestsData.error;
      if (premiumData.error) throw premiumData.error;
      if (messagesData.error) console.log('Messages not available yet');

      setSubscriptionRequests((requestsData.data || []) as SubscriptionRequest[]);
      setPremiumUsers(premiumData.data || []);
      setUserMessages((messagesData.data || []) as unknown as UserMessage[]);
    } catch (error) {
      console.error('Error loading data:', error);
      toast({
        title: "Error",
        description: "Failed to load data. Please refresh the page.",
        variant: "destructive",
      });
    }
  };

  const replyToMessage = async (messageId: string) => {
    const reply = replyText[messageId]?.trim();
    if (!reply) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('user_messages' as any)
        .update({
          reply,
          replied_at: new Date().toISOString()
        })
        .eq('id', messageId);

      if (error) throw error;

      toast({
        title: "Reply Sent!",
        description: "Your reply has been sent to the user.",
      });

      setReplyText(prev => ({ ...prev, [messageId]: '' }));
      loadData();
    } catch (error) {
      console.error('Error sending reply:', error);
      toast({
        title: "Error",
        description: "Failed to send reply. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const grantPremium = async (requestId: string, username: string, userId: string) => {
    try {
      // Update request status
      await supabase
        .from('subscription_requests')
        .update({ status: 'approved' })
        .eq('id', requestId);

      // Add to premium users (30 days from now)
      const { error } = await supabase
        .from('premium_users')
        .insert({
          user_id: userId,
          username,
          granted_by: user?.id,
          expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
          is_active: true
        });

      if (error) throw error;

      toast({
        title: "Premium Granted",
        description: `Premium access granted to ${username} for 30 days.`,
      });

      // Reload data
      loadData();
    } catch (error) {
      console.error('Error granting premium:', error);
      toast({
        title: "Error",
        description: "Failed to grant premium access. Please try again.",
        variant: "destructive",
      });
    }
  };

  const togglePremiumStatus = async (userId: string, currentStatus: boolean) => {
    try {
      await supabase
        .from('premium_users')
        .update({ is_active: !currentStatus })
        .eq('user_id', userId);

      toast({
        title: "Status Updated",
        description: `Premium status ${!currentStatus ? 'activated' : 'deactivated'}.`,
      });

      // Reload data
      loadData();
    } catch (error) {
      console.error('Error updating premium status:', error);
      toast({
        title: "Error",
        description: "Failed to update premium status. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (!isAuthorized) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/20 to-secondary/20 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle>Creator Access</CardTitle>
            <CardDescription>
              You need to be signed in with an authorized email to access the creator dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <Link to="/auth">
                <Button className="w-full mb-4">
                  Sign In
                </Button>
              </Link>
              <Link to="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Home
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingRequests = subscriptionRequests.filter(req => req.status === 'pending');
  const activePremiumUsers = premiumUsers.filter(user => {
    const expiryDate = new Date(user.expires_at);
    return expiryDate > new Date() && user.is_active;
  });
  const unreadMessages = userMessages.filter(msg => !msg.reply);

  const totalRequests = subscriptionRequests.length;
  const activePremium = activePremiumUsers.length;
  const pendingCount = pendingRequests.length;
  const monthlyRevenue = activePremium * 9.99; // Assuming $9.99/month

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Creator Dashboard</h1>
          <div className="flex items-center gap-4">
            <Badge variant="secondary">{user?.email}</Badge>
            <Button onClick={signOut} variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <Card className="p-4 text-center">
            <Users className="w-8 h-8 text-primary mx-auto mb-2" />
            <div className="text-2xl font-bold text-primary">{totalRequests}</div>
            <p className="text-sm text-muted-foreground">Total Requests</p>
          </Card>
          <Card className="p-4 text-center">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-green-600">{activePremium}</div>
            <p className="text-sm text-muted-foreground">Active Premium</p>
          </Card>
          <Card className="p-4 text-center">
            <Clock className="w-8 h-8 text-orange-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-orange-600">{pendingCount}</div>
            <p className="text-sm text-muted-foreground">Pending Approval</p>
          </Card>
          <Card className="p-4 text-center">
            <MessageSquare className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-blue-600">{unreadMessages.length}</div>
            <p className="text-sm text-muted-foreground">Unread Messages</p>
          </Card>
          <Card className="p-4 text-center">
            <DollarSign className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <div className="text-2xl font-bold text-emerald-600">${monthlyRevenue.toFixed(2)}</div>
            <p className="text-sm text-muted-foreground">Est. Monthly Revenue</p>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Pending Subscription Requests */}
          <Card className="p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Pending Requests
                <Badge variant="outline">{pendingCount}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="px-0">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {pendingRequests.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No pending requests</p>
                ) : (
                  pendingRequests.map((request) => (
                    <div key={request.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{request.username}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(request.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <Button 
                        onClick={() => grantPremium(request.id, request.username, request.user_id)}
                        size="sm"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Grant
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* User Messages */}
          <Card className="p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                User Messages
                <Badge variant="outline">{userMessages.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="px-0">
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {userMessages.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No messages</p>
                ) : (
                  userMessages.map((message) => (
                    <div key={message.id} className="space-y-3 border-b pb-4 last:border-b-0">
                      {/* User Message */}
                      <div className="bg-primary/5 p-3 rounded-lg">
                        <div className="flex items-center gap-2 mb-2">
                          <User className="w-4 h-4" />
                          <span className="font-medium text-sm">{message.username}</span>
                          {message.is_premium && (
                            <Badge variant="secondary" className="text-xs">Premium</Badge>
                          )}
                          <span className="text-xs text-muted-foreground ml-auto">
                            {new Date(message.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-sm">{message.message}</p>
                      </div>

                      {/* Reply Section */}
                      {message.reply ? (
                        <div className="bg-secondary/20 p-3 rounded-lg ml-4">
                          <div className="flex items-center gap-2 mb-2">
                            <div className="w-4 h-4 bg-primary rounded-full" />
                            <span className="font-medium text-sm text-primary">Your Reply</span>
                            <span className="text-xs text-muted-foreground ml-auto">
                              {message.replied_at && new Date(message.replied_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm">{message.reply}</p>
                        </div>
                      ) : (
                        <div className="ml-4 space-y-2">
                          <Textarea
                            placeholder="Type your reply..."
                            value={replyText[message.id] || ''}
                            onChange={(e) => setReplyText(prev => ({ ...prev, [message.id]: e.target.value }))}
                            rows={2}
                            className="text-sm"
                          />
                          <Button
                            size="sm"
                            onClick={() => replyToMessage(message.id)}
                            disabled={!replyText[message.id]?.trim() || loading}
                          >
                            <Send className="w-3 h-3 mr-1" />
                            Reply
                          </Button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Premium Users Management */}
          <Card className="p-6">
            <CardHeader className="px-0 pt-0">
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5" />
                Premium Users
                <Badge variant="outline">{premiumUsers.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="px-0">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {premiumUsers.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No premium users</p>
                ) : (
                  premiumUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{user.username}</p>
                        <p className="text-xs text-muted-foreground">
                          Expires: {new Date(user.expires_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className={user.is_active ? "bg-green-600" : "bg-gray-500"}>
                          {user.is_active ? "Active" : "Inactive"}
                        </Badge>
                        <Button
                          onClick={() => togglePremiumStatus(user.user_id, user.is_active)}
                          size="sm"
                          variant="outline"
                        >
                          {user.is_active ? (
                            <ToggleRight className="w-4 h-4" />
                          ) : (
                            <ToggleLeft className="w-4 h-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 text-center">
          <Link to="/">
            <Button variant="ghost">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}