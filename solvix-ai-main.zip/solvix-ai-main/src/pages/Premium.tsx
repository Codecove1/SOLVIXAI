import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Check, ArrowLeft, CreditCard, Phone, Mail, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export default function Premium() {
  const [username, setUsername] = useState('');
  const { toast } = useToast();
  const { user } = useAuth();

  const handleSubscription = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to submit a premium subscription request",
        variant: "destructive",
      });
      return;
    }

    if (!username.trim()) {
      toast({
        title: "Error",
        description: "Please enter your username",
        variant: "destructive",
      });
      return;
    }

    try {
      // Check if user already has a pending request
      const { data: existingRequest } = await supabase
        .from('subscription_requests')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'pending')
        .maybeSingle();

      if (existingRequest) {
        toast({
          title: "Request Already Exists",
          description: "You already have a pending subscription request",
          variant: "destructive",
        });
        return;
      }

      // Update user's profile with username
      await supabase
        .from('profiles')
        .upsert({
          user_id: user.id,
          username: username.trim(),
          email: user.email
        });

      // Create new subscription request
      const { error } = await supabase
        .from('subscription_requests')
        .insert({
          user_id: user.id,
          username: username.trim(),
          status: 'pending'
        });

      if (error) throw error;

      toast({
        title: "Request Submitted!",
        description: "Your premium subscription request has been submitted. You'll receive confirmation within 24 hours.",
      });

      setUsername('');
    } catch (error) {
      console.error('Error submitting request:', error);
      toast({
        title: "Error",
        description: "Failed to submit request. Please try again.",
        variant: "destructive",
      });
    }
  };

  const features = [
    "Unlimited questions daily",
    "GPT-5 AI Model (Most Advanced)",
    "Priority AI responses", 
    "Advanced study analytics",
    "24/7 customer support",
    "Offline study materials",
    "Progress tracking",
    "Custom study plans",
    "Performance insights",
    "Study reminders",
    "Priority support queue",
    "Multi-language support",
    "Export study notes",
    "Collaboration tools",
    "Advanced quiz generator"
  ];

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="p-4 bg-primary/10 rounded-full w-fit mx-auto mb-6">
            <CreditCard className="w-12 h-12 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Upgrade to Solvix Premium</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Unlock unlimited learning potential with our premium features designed for serious students.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="p-8">
            <div className="text-center mb-6">
              <h2 className="text-2xl font-bold mb-2">Premium Plan</h2>
              <div className="text-3xl font-bold text-primary">$20/month</div>
              <p className="text-muted-foreground">Everything you need to excel</p>
            </div>
            
            <div className="space-y-4 mb-8">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-primary flex-shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="username">Enter Your Username</Label>
                <Input 
                  id="username" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Your username"
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={handleSubscription}
                disabled={!username.trim() || !user}
                className="w-full"
                size="lg"
              >
                Submit Subscription Request
              </Button>
              {!user && (
                <p className="text-sm text-muted-foreground text-center">
                  Please <Link to="/auth" className="text-primary hover:underline">sign in</Link> to submit a request
                </p>
              )}
            </div>
          </Card>

          <Card className="p-8 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
            <div className="flex items-center gap-3 mb-4">
              <CreditCard className="w-6 h-6 text-primary" />
              <h3 className="text-xl font-semibold">Manual Payment Instructions</h3>
            </div>
            
            <p className="text-sm text-muted-foreground mb-6">
              Make a payment of <strong>$20 USD</strong> to the account below, then submit your username above. Your premium access will be activated once payment is confirmed.
            </p>
            
            <div className="space-y-4 mb-6">
              <div className="p-4 bg-card rounded-lg border">
                <Label className="text-sm font-medium text-muted-foreground">Account Name</Label>
                <p className="text-lg font-semibold">Nwachukwu Ololade Adeola</p>
              </div>
              <div className="p-4 bg-card rounded-lg border">
                <Label className="text-sm font-medium text-muted-foreground">Bank</Label>
                <p className="text-lg font-semibold">First Bank Nigeria</p>
              </div>
              <div className="p-4 bg-card rounded-lg border">
                <Label className="text-sm font-medium text-muted-foreground">Account Number</Label>
                <p className="text-lg font-semibold">3053321289</p>
              </div>
              <div className="p-4 bg-card rounded-lg border">
                <Label className="text-sm font-medium text-muted-foreground">Amount</Label>
                <p className="text-lg font-semibold text-primary">$20 USD per month</p>
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="flex items-center gap-3 mb-3">
                <Phone className="w-5 h-5 text-primary" />
                <h4 className="font-semibold">Customer Support</h4>
              </div>
              <p className="text-sm text-muted-foreground mb-2">
                For assistance with payments or account activation:
              </p>
              <p className="text-lg font-semibold text-primary">08148952255</p>
            </div>

            <div className="mt-6 p-4 bg-primary/10 rounded-lg border border-primary/20">
              <p className="text-sm">
                <strong>Payment Process:</strong> After making the payment, submit your username above. Our team will verify the payment and activate your premium access within 24 hours.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}