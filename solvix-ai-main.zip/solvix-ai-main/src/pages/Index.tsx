import { useState, useEffect } from 'react';
import { RealtimeAIInterface } from '@/components/RealtimeAIInterface';
import { SolvixHeader } from '@/components/SolvixHeader';
import { StudyTips } from '@/components/StudyTips';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Crown, Zap, BarChart3, Headphones, Camera, Clock, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { useRealtimePremium } from '@/hooks/useRealtimePremium';
import { RealtimeNotifications } from '@/components/RealtimeNotifications';

export default function Index() {
  const [isDark, setIsDark] = useState(false);
  const [questionsUsed, setQuestionsUsed] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isPremium, loading: premiumLoading } = useRealtimePremium();

  const freeLimit = 5;
  const questionsLeft = Math.max(0, freeLimit - questionsUsed);
  const canAsk = isPremium || questionsLeft > 0;

  useEffect(() => {
    // Apply theme class to document
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Redirect to auth if not logged in
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  const handleQuestionSubmit = (question: string, type?: 'text' | 'image' | 'voice') => {
    if (!isPremium) {
      setQuestionsUsed(prev => prev + 1);
    }
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      if (!isPremium && questionsUsed + 1 >= freeLimit) {
        toast({
          title: "Free limit reached!",
          description: "Upgrade to Premium for unlimited questions.",
        });
      }
    }, 2000);
  };

  const handleUpgrade = () => {
    navigate('/premium');
  };

  if (authLoading || premiumLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-secondary/20">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-2 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Loading Solvix...</p>
        </div>
      </div>
    );
  }

  // Premium upgrade screen for free users who reached limit
  if (!isPremium && questionsUsed >= freeLimit) {
    return (
      <div className="min-h-screen bg-background">
        <SolvixHeader 
          isDark={isDark}
          onThemeToggle={() => setIsDark(!isDark)}
          questionsLeft={questionsLeft}
          isPremium={isPremium}
        />
        
        <div className="flex items-center justify-center min-h-[calc(100vh-80px)] p-4">
          <Card className="max-w-md w-full p-6 text-center space-y-6">
            <div className="p-4 bg-primary/10 rounded-full w-fit mx-auto">
              <Crown className="w-8 h-8 text-primary" />
            </div>
            
            <div className="space-y-2">
              <h2 className="text-2xl font-bold">Upgrade to Premium</h2>
              <p className="text-muted-foreground">
                You've used all your free questions for today. Upgrade to Premium for unlimited access!
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg">
                <h3 className="font-semibold mb-2">Premium Benefits</h3>
                <ul className="text-sm text-muted-foreground space-y-1 text-left">
                  <li>• Unlimited questions daily</li>
                  <li>• Priority AI responses</li>
                  <li>• Advanced study analytics</li>
                  <li>• Voice input & output</li>
                  <li>• Homework photo analysis</li>
                  <li>• 24/7 customer support</li>
                  <li>• Offline study materials</li>
                  <li>• Progress tracking</li>
                </ul>
              </div>
              
              <Button onClick={handleUpgrade} className="w-full" size="lg">
                <Zap className="w-4 h-4 mr-2" />
                Upgrade Now
              </Button>
              
              <Button 
                variant="ghost" 
                onClick={() => {
                  setQuestionsUsed(0);
                  toast({ title: "Questions reset", description: "For demo purposes only!" });
                }}
                className="w-full"
              >
                Reset Questions (Demo)
              </Button>
            </div>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <RealtimeNotifications />
      <SolvixHeader 
        isDark={isDark} 
        onThemeToggle={() => setIsDark(!isDark)}
        questionsLeft={questionsLeft}
        isPremium={isPremium}
      />
      
      {/* Main Content */}
      <main className="flex-1 p-6 overflow-hidden">
        <div className="max-w-4xl mx-auto h-full flex flex-col gap-6">
          {/* Chat Interface */}
          <div className="flex-1 bg-card rounded-lg border shadow-sm">
            <RealtimeAIInterface 
              onQuestionSubmit={handleQuestionSubmit}
              isLoading={isLoading}
              canAsk={canAsk}
              isPremium={isPremium}
            />
          </div>
          
          <Separator className="my-4" />
          
          {/* Study Tips */}
          <StudyTips />
        </div>
      </main>

      {/* Premium upgrade section for free users */}
      {!isPremium && (
        <div className="border-t bg-card/50 p-4">
          <div className="max-w-4xl mx-auto">
            <Card className="p-4 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Crown className="w-5 h-5 text-primary" />
                  <div>
                    <h3 className="font-semibold">Go Premium for Ultimate Study Power</h3>
                    <p className="text-sm text-muted-foreground">
                      Unlock unlimited questions, voice input, photo analysis, and more!
                    </p>
                  </div>
                </div>
                <Button onClick={handleUpgrade} className="shrink-0">
                  <Zap className="w-4 h-4 mr-2" />
                  Upgrade Now
                </Button>
              </div>
            </Card>
          </div>
        </div>
      )}

      {/* Footer section separator */}
      <div className="border-t bg-card/30 p-4 mt-8">
        <div className="max-w-4xl mx-auto text-center">
          <p className="text-sm text-muted-foreground">
            Sections: AI Chat • Study Tips • Premium Features • Support
          </p>
        </div>
      </div>
      
      <footer className="border-t p-4 text-center text-sm text-muted-foreground">
        <p>© 2025 Solvix - Your AI Study Assistant</p>
      </footer>
    </div>
  );
}