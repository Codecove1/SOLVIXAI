import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Send, MessageSquare, User, Crown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useSupabasePremium } from '@/hooks/useSupabasePremium';

interface Message {
  id: string;
  user_id: string;
  username: string;
  message: string;
  is_premium: boolean;
  created_at: string;
  reply?: string;
  replied_at?: string;
}

export default function Messages() {
  const [message, setMessage] = useState('');
  const [userMessages, setUserMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { isPremium } = useSupabasePremium();

  useEffect(() => {
    if (user) {
      fetchUserMessages();
      
      // Set up real-time subscription for message updates
      const channel = supabase
        .channel('user-messages-changes')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'user_messages',
            filter: `user_id=eq.${user.id}`
          },
          (payload) => {
            console.log('Message change received:', payload);
            fetchUserMessages(); // Refresh messages on any change
            
            // Show notification for new replies
            if (payload.eventType === 'UPDATE' && payload.new?.reply) {
              toast({
                title: "New Reply!",
                description: "The creator has replied to your message.",
              });
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
      };
    }
  }, [user, toast]);

  const fetchUserMessages = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('user_messages' as any)
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUserMessages((data as unknown as Message[]) || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim() || !user) return;
    
    setLoading(true);
    
    try {
      // Get username from user metadata or profiles table
      let username = user.user_metadata?.username || 'Anonymous';
      
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('username')
          .eq('user_id', user.id)
          .single();
        
        if (profile?.username) {
          username = profile.username;
        }
      } catch (profileError) {
        console.log('No profile found, using metadata username');
      }

      const { error } = await supabase
        .from('user_messages' as any)
        .insert({
          user_id: user.id,
          username: username,
          message: message.trim(),
          is_premium: isPremium
        });

      if (error) throw error;

      toast({
        title: "Message Sent!",
        description: "Your message has been sent to the creator. You'll receive a reply soon.",
      });

      setMessage('');
      fetchUserMessages();
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <div className="text-center mb-12">
          <div className="p-4 bg-primary/10 rounded-full w-fit mx-auto mb-6">
            <MessageSquare className="w-12 h-12 text-primary" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Message the Creator</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Have questions, feedback, or need support? Send a message directly to the Solvix creator.
          </p>
        </div>

        <div className="grid gap-8 mb-12">
          {/* Send Message Card */}
          <Card className="p-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Send className="w-5 h-5" />
                Send New Message
                {isPremium && (
                  <Badge variant="secondary">
                    <Crown className="w-3 h-3 mr-1" />
                    Premium
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Send your questions, feedback, or support requests directly to the creator.
                {isPremium && " Premium users receive priority responses."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message here... (questions, feedback, support requests, etc.)"
                  rows={6}
                  className="resize-none"
                />
                <div className="flex justify-between items-center">
                  <p className="text-sm text-muted-foreground">
                    {user?.user_metadata?.username || user?.email || 'Anonymous'} • {isPremium ? 'Premium User' : 'Free User'}
                  </p>
                  <Button 
                    type="submit" 
                    disabled={!message.trim() || loading}
                    className="min-w-24"
                  >
                    {loading ? (
                      <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          {/* Message History */}
          {userMessages.length > 0 && (
            <Card className="p-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Your Messages
                </CardTitle>
                <CardDescription>
                  View your previous messages and replies from the creator.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {userMessages.map((msg) => (
                    <div key={msg.id} className="space-y-4">
                      {/* User Message */}
                      <div className="bg-primary/5 p-4 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span className="font-medium">{msg.username}</span>
                            {msg.is_premium && (
                              <Badge variant="secondary" className="text-xs">
                                <Crown className="w-3 h-3 mr-1" />
                                Premium
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">
                            {new Date(msg.created_at).toLocaleDateString()}
                          </span>
                        </div>
                        <p className="text-sm">{msg.message}</p>
                      </div>

                      {/* Creator Reply */}
                      {msg.reply && (
                        <div className="bg-secondary/20 p-4 rounded-lg ml-6">
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 bg-primary rounded-full" />
                              <span className="font-medium text-primary">Creator Reply</span>
                            </div>
                            <span className="text-xs text-muted-foreground">
                              {msg.replied_at && new Date(msg.replied_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-sm">{msg.reply}</p>
                        </div>
                      )}

                      {!msg.reply && (
                        <div className="ml-6 p-3 bg-muted/50 rounded-lg">
                          <p className="text-sm text-muted-foreground italic">
                            Waiting for creator reply...
                          </p>
                        </div>
                      )}
                      
                      <Separator />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {userMessages.length === 0 && (
            <Card className="p-6 text-center">
              <div className="py-8">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Messages Yet</h3>
                <p className="text-muted-foreground">
                  Send your first message to get started! The creator will reply as soon as possible.
                </p>
              </div>
            </Card>
          )}
        </div>

        {/* Contact Info */}
        <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
          <CardHeader>
            <CardTitle>Quick Contact Information</CardTitle>
            <CardDescription>
              For urgent matters, you can also contact us directly.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-card rounded-lg border">
                <h4 className="font-semibold mb-2">Customer Support</h4>
                <p className="text-lg font-semibold text-primary">08148952255</p>
                <p className="text-sm text-muted-foreground">
                  Available for premium users and urgent support
                </p>
              </div>
              <div className="p-4 bg-card rounded-lg border">
                <h4 className="font-semibold mb-2">Response Time</h4>
                <p className="text-lg font-semibold text-primary">
                  {isPremium ? "Within 4 hours" : "Within 24 hours"}
                </p>
                <p className="text-sm text-muted-foreground">
                  {isPremium ? "Priority support for premium users" : "Standard response time"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}