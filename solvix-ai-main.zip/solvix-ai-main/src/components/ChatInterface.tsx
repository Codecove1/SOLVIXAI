import { useState } from "react";
import { Send, Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
  subject?: string;
  saved?: boolean;
}

interface ChatInterfaceProps {
  onQuestionSubmit: (question: string, image?: File) => void;
  isLoading: boolean;
  canAsk: boolean;
}

export const ChatInterface = ({ onQuestionSubmit, isLoading, canAsk }: ChatInterfaceProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      content: "Hi there! 👋 I'm Solvix, your friendly AI study assistant. I'm here to help you with homework, explain concepts, and make learning fun! What would you like to study today?",
      isUser: false,
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState("");
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !canAsk || isLoading) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      content: input,
      isUser: true,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newMessage]);
    setInput("");
    
    // Simulate AI response
    onQuestionSubmit(input);
    
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: `Great question! Let me help you understand this step by step. ${input.toLowerCase().includes('math') ? 'For this math problem, I\'ll break it down into simple steps...' : input.toLowerCase().includes('science') ? 'This is an interesting science concept! Let me explain it clearly...' : 'Here\'s a detailed explanation to help you learn...'}`,
        isUser: false,
        timestamp: new Date(),
        subject: input.toLowerCase().includes('math') ? 'Mathematics' : input.toLowerCase().includes('science') ? 'Science' : 'General'
      };
      setMessages(prev => [...prev, aiResponse]);
    }, 2000);
  };


  const saveMessage = (messageId: string) => {
    setMessages(prev => 
      prev.map(msg => 
        msg.id === messageId ? { ...msg, saved: true } : msg
      )
    );
    toast({
      title: "Saved!",
      description: "Added to your study collection"
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}
          >
            <Card className={`max-w-[80%] p-3 ${
              message.isUser 
                ? "bg-primary text-primary-foreground" 
                : "bg-card"
            }`}>
              <div className="space-y-2">
                <p className="text-sm leading-relaxed">{message.content}</p>
                {message.subject && (
                  <Badge variant="secondary" className="text-xs">
                    {message.subject}
                  </Badge>
                )}
                <div className="flex items-center justify-between text-xs opacity-70">
                  <span>{message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  {!message.isUser && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => saveMessage(message.id)}
                      className={`p-1 h-auto ${message.saved ? 'text-primary' : ''}`}
                    >
                      <Save className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <Card className="p-3 bg-card">
              <div className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="text-sm">Solvix is thinking...</span>
              </div>
            </Card>
          </div>
        )}
      </div>

      <div className="p-4 border-t bg-card/50 backdrop-blur-sm">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={canAsk ? "Ask me anything about your studies..." : "Upgrade to Premium for more questions!"}
              className="flex-1 min-h-[40px] max-h-32 resize-none"
              disabled={!canAsk || isLoading}
            />
          </div>
          
          <Button
            type="submit"
            disabled={!input.trim() || !canAsk || isLoading}
            className="w-full"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin mr-2" />
            ) : (
              <Send className="w-4 h-4 mr-2" />
            )}
            {isLoading ? "Processing..." : "Send Question"}
          </Button>
        </form>
      </div>
    </div>
  );
};