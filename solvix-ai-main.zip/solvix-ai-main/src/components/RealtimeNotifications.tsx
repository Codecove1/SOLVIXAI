import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';

export const RealtimeNotifications = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (!user) return;

    // Subscribe to real-time notifications for various events
    const notificationsChannel = supabase
      .channel('global-notifications')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'subscription_requests'
        },
        (payload) => {
          // Only show if it's the current user's request
          if (payload.new?.user_id === user.id) {
            toast({
              title: "Request Submitted!",
              description: "Your premium subscription request has been submitted and is being reviewed.",
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'subscription_requests'
        },
        (payload) => {
          // Only show if it's the current user's request and status changed to approved
          if (payload.new?.user_id === user.id && payload.new?.status === 'approved') {
            toast({
              title: "🎉 Request Approved!",
              description: "Your premium subscription request has been approved!",
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(notificationsChannel);
    };
  }, [user, toast]);

  return null; // This component only handles notifications
};