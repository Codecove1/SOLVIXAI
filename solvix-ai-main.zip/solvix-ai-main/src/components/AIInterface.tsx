import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Send, Loader2, Crown, Zap } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type?: 'text';
}

interface AIInterfaceProps {
  onQuestionSubmit: (question: string, type?: 'text' | 'image' | 'voice') => void;
  isLoading: boolean;
  canAsk: boolean;
  isPremium: boolean;
}

export const AIInterface = ({ onQuestionSubmit, isLoading, canAsk, isPremium }: AIInterfaceProps) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const streamingMessageRef = useRef('');
  const { toast } = useToast();
  const { user } = useAuth();

  // WebSocket setup with fallback
  useEffect(() => {
    let reconnectAttempts = 0;
    const maxReconnectAttempts = 3;
    
    const connectWebSocket = () => {
      try {
        console.log(`Attempting WebSocket connection (attempt ${reconnectAttempts + 1})`);
        const wsUrl = `wss://qprqckiyprusdunwzobw.supabase.co/functions/v1/realtime-grok`;
        const websocket = new WebSocket(wsUrl);
        
        websocket.onopen = () => {
          console.log('Connected to real-time Llama AI');
          setWs(websocket);
          reconnectAttempts = 0; // Reset on successful connection
          
          toast({
            title: "🚀 Offline Ready!",
            description: "Connected to Offline Study Assistant",
          });
        };
        
        websocket.onmessage = (event) => {
          const data = JSON.parse(event.data);
          console.log('WebSocket message:', data);
          
          if (data.type === 'typing') {
            setIsStreaming(true);
            setIsAiLoading(true);
            setStreamingMessage('');
            streamingMessageRef.current = '';
          } else if (data.type === 'stream') {
            const newContent = data.content || '';
            streamingMessageRef.current += newContent;
            setStreamingMessage(prev => prev + newContent);
          } else if (data.type === 'stream_end') {
            setIsStreaming(false);
            setIsAiLoading(false);
            
            // Add the completed message to messages using the ref value
            const finalContent = streamingMessageRef.current;
            if (finalContent.trim()) {
              const aiMessage: Message = {
                id: Date.now().toString(),
                content: finalContent,
                sender: 'ai',
                timestamp: new Date(),
                type: 'text'
              };
              
              setMessages(prev => [...prev, aiMessage]);
            }
            setStreamingMessage('');
            streamingMessageRef.current = '';
          } else if (data.type === 'error') {
            setIsStreaming(false);
            setIsAiLoading(false);
            toast({
              title: "Error",
              description: data.message,
              variant: "destructive",
            });
          }
        };
        
        websocket.onerror = (error) => {
          console.error('WebSocket error:', error);
          reconnectAttempts++;
          
          if (reconnectAttempts >= maxReconnectAttempts) {
            toast({
              title: "Connection Failed",
              description: "Switching to standard mode. Real-time features may be limited.",
              variant: "destructive",
            });
          }
        };
        
        websocket.onclose = () => {
          console.log('WebSocket connection closed');
          setWs(null);
          
          // Only auto-reconnect if we haven't exceeded max attempts
          if (reconnectAttempts < maxReconnectAttempts) {
            setTimeout(() => {
              reconnectAttempts++;
              connectWebSocket();
            }, 3000);
          }
        };
        
      } catch (error) {
        console.error('Failed to create WebSocket:', error);
        reconnectAttempts++;
        
        if (reconnectAttempts < maxReconnectAttempts) {
          setTimeout(() => {
            connectWebSocket();
          }, 3000);
        }
      }
    };
    
    connectWebSocket();
    
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, []);

  const sendMessageToAI = async (userMessage: string) => {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'chat',
        message: userMessage,
        userId: user?.id || 'anonymous',
        isPremium: isPremium
      }));
    } else {
      // Fallback to HTTP endpoint if WebSocket is not available
      console.log('WebSocket not available, using HTTP fallback');
      setIsAiLoading(true);
      
      try {
        const { data, error } = await supabase.functions.invoke('ai-chat', {
          body: {
            message: userMessage,
            userId: user?.id || 'anonymous',
            isPremium: isPremium
          }
        });

        if (error) {
          console.error('AI function error:', error);
          throw new Error('AI service error');
        }

        const aiResponse = data.response || "I'm sorry, I couldn't generate a response. Please try again.";
        
        // Add AI response to messages
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: aiResponse,
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };

        setMessages(prev => [...prev, aiMessage]);
        
      } catch (error) {
        console.error('AI generation error:', error);
        toast({
          title: "AI Error",
          description: "Failed to get AI response. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsAiLoading(false);
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!input.trim() || !canAsk) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      sender: 'user',
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    onQuestionSubmit(input.trim(), 'text');
    
    // Send to real-time AI
    await sendMessageToAI(input.trim());
    setInput('');
  };


  return (
    <div className="flex flex-col h-full max-h-[600px]">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <div className="text-center py-8">
            <div className="p-4 bg-primary/10 rounded-lg inline-block">
              <h3 className="font-semibold text-primary mb-2">Hi! I'm Solvix 🤖</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Ask me any study-related question and I'll help you learn!
              </p>
              <div className="flex items-center justify-center gap-2 mt-2">
                 <Badge variant="secondary">
                   <Zap className="w-3 h-3 mr-1" />
                   Powered by Offline AI
                 </Badge>
                {isPremium && (
                  <Badge variant="default">
                    <Crown className="w-3 h-3 mr-1" />
                    Premium Features Active
                  </Badge>
                )}
              </div>
            </div>
          </div>
        ) : (
          messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <Card className={`max-w-[80%] p-3 ${
                message.sender === 'user' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted'
              }`}>
                <p className="text-sm">{message.content}</p>
                <p className="text-xs opacity-70 mt-1">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </Card>
            </div>
          ))
         )}
         
         {/* Streaming message display */}
         {isStreaming && streamingMessage && (
           <div className="flex justify-start">
             <Card className="bg-muted p-3 max-w-[80%]">
               <p className="text-sm">{streamingMessage}</p>
               <div className="flex items-center gap-2 mt-2">
                 <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                 <span className="text-xs opacity-70">Offline AI is typing...</span>
                 <Badge variant="secondary" className="ml-2">
                   <Zap className="w-3 h-3 mr-1" />
                   Real-time
                 </Badge>
               </div>
             </Card>
           </div>
         )}
         
         {(isLoading || isAiLoading) && !isStreaming && (
           <div className="flex justify-start">
             <Card className="bg-muted p-3">
               <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-sm">Connecting to Llama AI...</span>
                  <Badge variant="secondary" className="ml-2">
                    <Zap className="w-3 h-3 mr-1" />
                    Llama 3.1
                  </Badge>
                 {isPremium && (
                   <Badge variant="default" className="ml-1">
                     <Crown className="w-3 h-3 mr-1" />
                     Premium
                   </Badge>
                 )}
               </div>
             </Card>
           </div>
         )}
      </div>

      <form onSubmit={handleSubmit} className="p-4 border-t bg-card">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={canAsk ? "Ask me anything about your studies..." : "Upgrade to Premium for unlimited questions"}
              disabled={!canAsk || isLoading}
              className="min-h-[40px] resize-none pr-20"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
            />
          </div>
          
          <Button
            type="submit"
            size="sm"
            disabled={!canAsk || !input.trim() || isLoading}
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
      </form>
    </div>
  );
};