import { Lightbulb, TrendingUp, Clock, BookOpen } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const dailyTips = [
  {
    icon: Clock,
    category: "Time Management",
    tip: "Use the Pomodoro technique: 25 minutes of focused study, then a 5-minute break!"
  },
  {
    icon: BookOpen,
    category: "Reading",
    tip: "Read actively by summarizing each paragraph in your own words."
  },
  {
    icon: TrendingUp,
    category: "Memory",
    tip: "Review material within 24 hours to improve retention by up to 60%!"
  },
  {
    icon: Lightbulb,
    category: "Problem Solving", 
    tip: "Break complex problems into smaller steps - it makes everything more manageable!"
  }
];

export const StudyTips = () => {
  const todaysTip = dailyTips[new Date().getDate() % dailyTips.length];
  const Icon = todaysTip.icon;

  return (
    <Card className="p-4 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/20">
      <div className="flex items-start gap-3">
        <div className="p-2 bg-primary/20 rounded-lg">
          <Icon className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm">Daily Study Tip</h3>
            <Badge variant="secondary" className="text-xs">
              {todaysTip.category}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {todaysTip.tip}
          </p>
        </div>
      </div>
    </Card>
  );
};